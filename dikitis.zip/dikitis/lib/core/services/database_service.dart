import 'package:get_storage/get_storage.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static final GetStorage _dbInstance = GetStorage();

  DatabaseService._internal();

  factory DatabaseService() {
    return _instance;
  }

  static Future<void> init() async {
    await GetStorage.init();
  }

  Future<void> write(String key, dynamic data) async {
    await _dbInstance.write(key, data);
  }

  dynamic read(String key) {
    return _dbInstance.read(key);
  }

  Future<void> remove(String key) async {
    await _dbInstance.remove(key);
  }
}
