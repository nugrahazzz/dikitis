import 'package:awesome_dio_interceptor/awesome_dio_interceptor.dart';
import 'package:dikitis/core/constant/api/api_path.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

class RestApiService {
  final Dio dio;

  RestApiService({required this.dio}) {
    _initializeDio();
  }

  void _initializeDio() {
    dio.options.headers['content-type'] = 'application/json';
    if (kDebugMode) {
      print("initializeDio");
    }

    dio.options = BaseOptions(
        baseUrl: ApiPath.baseUrl,
        followRedirects: false,
        validateStatus: (int? status) {
          return status! <= 500;
        },
        contentType: Headers.jsonContentType,
        responseType: ResponseType.json,
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        receiveDataWhenStatusError: true,
        receiveTimeout: const Duration(seconds: 15),
        sendTimeout: const Duration(seconds: 15),
        connectTimeout: const Duration(seconds: 15));

    if (kDebugMode) {
      dio.interceptors.add(
        AwesomeDioInterceptor(
          // Disabling headers and timeout would minimize the logging output.
          // Optional, defaults to true
          logRequestTimeout: false,
          logRequestHeaders: false,
          logResponseHeaders: false,

          // Optional, defaults to the 'log' function in the 'dart:developer' package.
          logger: debugPrint,
        ),
      );
    }
  }

  Future<Response> get({required String endPoint, dynamic data, dynamic params}) async {
    var response = await dio.get(endPoint, data: data, queryParameters: params);
    return handleResponse(response: response);
  }

  Future<Response> post({required String endPoint, dynamic data, dynamic params}) async {
    var response = await dio.post(endPoint, data: data, queryParameters: params);
    return handleResponse(response: response);
  }

  Future<Response> put({required String endPoint}) async {
    var response = await dio.put(endPoint);
    return response;
  }

  Future<Response> delete({required String endPoint}) async {
    var response = await dio.delete(endPoint);
    return response;
  }

  Response handleResponse({required Response response}) {
    if (response.statusCode == 200) {
      return response;
    } else if (response.statusCode == 400) {
      throw DataSource.badRequest.getFailure();
    } else if (response.statusCode == 401) {
      throw DataSource.unauthorised.getFailure();
    } else if (response.statusCode == 403) {
      throw DataSource.forbidden.getFailure();
    } else if (response.statusCode == 404) {
      throw DataSource.notFound.getFailure();
    } else if (response.statusCode == 500) {
      throw DataSource.internalServerError.getFailure();
    } else {
      throw DataSource.custom.setFailure(response.toString());
    }
  }
}
