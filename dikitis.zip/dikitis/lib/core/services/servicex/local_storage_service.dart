import 'package:get_storage/get_storage.dart';

/// **LocalStorageService:** Mengelola penyimpanan data lokal dengan GetStorage
class LocalStorageService {
  final GetStorage _storage = GetStorage();

  /// **Kunci penyimpanan untuk data pengguna dan pengaturan aplikasi**
  static const String _userDataKey = "userData";
  static const String _isLoggedKey = "isLogged";

  /// **Menyimpan status login pengguna**
  Future<void> setIsLogged(bool status) async => await _storage.write(_isLoggedKey, status);

  /// **Mengecek status login pengguna (default: false)**
  bool getIsLogged() => _storage.read(_isLoggedKey) ?? false;

  /// **Menyimpan data pengguna dalam format JSON**
  Future<void> setUserData(Map<String, dynamic> userJson) async {
    await _storage.write(_userDataKey, userJson);
  }

  /// **Mendapatkan data pengguna dalam bentuk JSON (nullable)**
  Map<String, dynamic>? getUserData() {
    return _storage.read(_userDataKey);
  }

  /// **Menghapus data pengguna**
  Future<void> clearUserData() async {
    await _storage.remove(_userDataKey);
    await _storage.write(_isLoggedKey, false);
  }
}
