import 'dart:async';
import 'dart:io';

import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

class ErrorHandler implements Exception {
  late Failure failure;

  ErrorHandler.handle(dynamic error) {
    if (error is DioException) {
      // dio error so its an error from response of the API or from dio itself
      failure = _handleError(error);
    } else if (error is FormatException) {
      failure = DataSource.parserError.getFailure();
    } else if (error is TimeoutException) {
      failure = DataSource.connectTimeout.getFailure();
    } else if (error is SocketException) {
      failure = DataSource.noInternetConnection.getFailure();
    } else {
      failure = Failure(
        ResponseCode.custom,
        error.toString(),
      );
    }
  }
}

Failure _handleError(DioException error) {
  if (kDebugMode) {
    print(error.type);
  }
  switch (error.type) {
    case DioExceptionType.badResponse:
      return DataSource.badRequest.getFailure();
    case DioExceptionType.connectionTimeout:
      return DataSource.connectTimeout.getFailure();
    case DioExceptionType.sendTimeout:
      return DataSource.sendTimeout.getFailure();
    case DioExceptionType.receiveTimeout:
      return DataSource.failure.getFailure();
    case DioExceptionType.connectionError:
      return DataSource.noInternetConnection.getFailure();
    case DioExceptionType.cancel:
      return DataSource.cancel.getFailure();
    case DioExceptionType.unknown:
      return DataSource.unknown.getFailure();
    default:
      return DataSource.failure.getFailure();
    // return DataSourcex.custom.setFailure(error.toString());
  }
}

extension DataSourceExtension on DataSource {
  Failure getFailure() {
    switch (this) {
      case DataSource.success:
        return Failure(ResponseCode.success, ResponseMessage.success);
      case DataSource.noContent:
        return Failure(ResponseCode.noContent, ResponseMessage.noContent);
      case DataSource.badRequest:
        return Failure(ResponseCode.badRequest, ResponseMessage.badRequest);
      case DataSource.forbidden:
        return Failure(ResponseCode.forbidden, ResponseMessage.forbidden);
      case DataSource.unauthorised:
        return Failure(ResponseCode.unauthorised, ResponseMessage.unauthorised);
      case DataSource.notFound:
        return Failure(ResponseCode.notFound, ResponseMessage.notFound);
      case DataSource.internalServerError:
        return Failure(ResponseCode.internalServerError, ResponseMessage.internalServerError);
      case DataSource.connectTimeout:
        return Failure(ResponseCode.connectTimeout, ResponseMessage.connectTimeout);
      case DataSource.cancel:
        return Failure(ResponseCode.cancel, ResponseMessage.cancel);
      case DataSource.failure:
        return Failure(ResponseCode.receiveTimeout, ResponseMessage.failure);
      case DataSource.sendTimeout:
        return Failure(ResponseCode.sendTimeout, ResponseMessage.sendTimeout);
      case DataSource.cacheError:
        return Failure(ResponseCode.cacheError, ResponseMessage.cacheError);
      case DataSource.noInternetConnection:
        return Failure(ResponseCode.noInternetConnection, ResponseMessage.noInternetConnection);
      case DataSource.unknown:
        return Failure(ResponseCode.unknownError, ResponseMessage.unknownError);

      case DataSource.parserError:
        return Failure(ResponseCode.parserError, ResponseMessage.parserError);
      case DataSource.custom:
        return Failure(ResponseCode.custom, ResponseMessage.custom);
    }
  }

  Failure setFailure(String message) {
    return Failure(
      ResponseCode.custom,
      message,
    );
  }
}

class ResponseCode {
  // Server status code
  static const int success = 200; // success with data
  static const int noContent = 201; // success with no data (no content)
  static const int badRequest = 400; // failure, API rejected request
  static const int unauthorised = 401; // failure, user is not authorised
  static const int forbidden = 403; // failure, API rejected request
  static const int notFound = 404; // failure, not found
  static const int internalServerError = 500; // failure, crash in server side

  // Local status code
  static const int connectTimeout = -1;
  static const int cancel = -2;
  static const int receiveTimeout = -3;
  static const int sendTimeout = -4;
  static const int cacheError = -5;
  static const int noInternetConnection = -6;
  static const int custom = -7;
  static const int connectionError = -8;
  static const int parserError = -9;
  static const int unknownError = -10;
}

class ResponseMessage {
  static const String success = AppStrings.success; // success with data
  static const String noContent = AppStrings.strNoContent; // success with no data (no content)
  static const String badRequest = AppStrings.strBadRequestError; // failure, API rejected request
  static const String unauthorised = AppStrings.strUnauthorizedError; // failure, user is not authorised
  static const String forbidden = AppStrings.strForbiddenError; // failure, API rejected request
  static const String internalServerError = AppStrings.strInternalServerError; // failure, crash in server side
  static const String notFound = AppStrings.strNotFoundError; // failure, not found

  // Local status code
  static const String connectTimeout = AppStrings.strTimeoutError;
  static const String cancel = AppStrings.strDefaultError;
  static const String failure = AppStrings.strTimeoutError;
  static const String sendTimeout = AppStrings.strTimeoutError;
  static const String cacheError = AppStrings.strCacheError;
  static const String noInternetConnection = AppStrings.strNoInternetError;
  static const String custom = AppStrings.strDefaultError;
  static const String parserError = AppStrings.strParserError;
  static const String unknownError = AppStrings.strUnknownError;
}

class AppStrings {
  static const strNoRouteFound = "The route you requested does not exist in this application";

  // Menunjukkan bahwa rute atau halaman yang diminta oleh pengguna tidak ada dalam aplikasi ini, kemungkinan karena kesalahan pengetikan URL atau perubahan struktur aplikasi.

  static const strAppName = "app_name";

  // Nama aplikasi yang digunakan untuk menampilkan nama aplikasi di berbagai tampilan antarmuka pengguna.

  static const String success = "The operation was successful";

  // Pesan yang digunakan untuk memberi tahu bahwa tindakan atau operasi telah berhasil dilakukan tanpa masalah.

  static const String strBadRequestError = "The server could not understand the request due to invalid syntax";

  // Kesalahan ini terjadi ketika server tidak dapat memahami permintaan karena sintaks yang tidak valid, sering kali terkait dengan format data yang salah atau parameter yang hilang.

  static const String strNoContent = "The server successfully processed the request, but no content is returned";

  // Digunakan ketika server berhasil memproses permintaan, tetapi tidak ada data atau konten yang dapat dikembalikan, umumnya untuk status HTTP 204.

  static const String strForbiddenError = "You do not have permission to access the requested resource";

  // Menunjukkan bahwa pengguna tidak memiliki izin untuk mengakses sumber daya yang diminta, meskipun permintaan tersebut valid.

  static const String strUnauthorizedError = "You need to be authenticated to access this resource";

  // Menunjukkan bahwa pengguna perlu login atau autentikasi untuk dapat mengakses sumber daya yang diminta.

  static const String strNotFoundError = "The resource you are looking for could not be found on this server. Please verify the URL";

  // Menunjukkan bahwa server tidak dapat menemukan sumber daya yang diminta, biasanya mengarah pada kesalahan 404. Meminta pengguna untuk memeriksa kembali URL.

  static const String strConflictError = "The request could not be completed due to a conflict with the current state of the server";

  // Terjadi ketika ada konflik antara permintaan dan status server saat ini, misalnya jika mencoba untuk menambahkan data yang sudah ada.

  static const String strInternalServerError = "An error occurred on the server, and the request could not be completed";

  // Kesalahan server internal yang terjadi ketika server tidak dapat memproses permintaan karena masalah internal, seperti kesalahan pengolahan data.

  static const String strUnknownError = "An unexpected error occurred. Please try again later";

  // Digunakan untuk kesalahan yang tidak dapat dipahami atau dikategorikan, memberi tahu pengguna untuk mencoba lagi nanti.

  static const String strTimeoutError = "The server took too long to respond. Please check your connection";

  // Menunjukkan bahwa waktu yang ditunggu untuk respons server telah habis, biasanya karena masalah jaringan atau server yang terlalu lambat.

  static const String strDefaultError = "An error occurred, but the cause is unknown";

  // Menyediakan pesan kesalahan umum ketika aplikasi tidak dapat memproses atau mengidentifikasi penyebab kesalahan dengan jelas.

  static const String strCacheError = "An error occurred while trying to read or write cached data";

  // Digunakan ketika ada masalah dalam membaca atau menyimpan data ke cache, yang dapat menyebabkan data yang lama atau tidak valid digunakan.

  static const String strNoInternetError = "No internet connection is available. Please check your network settings and try again";

  // Menunjukkan bahwa perangkat tidak dapat terhubung ke internet, memberi tahu pengguna untuk memeriksa pengaturan jaringan atau Wi-Fi mereka.

  static const String strParserError = "There was an issue while processing the data received. Please ensure the data format is correct";
// Kesalahan ini terjadi ketika data yang diterima dari server tidak dapat diproses dengan benar, mungkin karena format data yang tidak sesuai (misalnya, JSON yang rusak).
}
