import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class AppColors {
  static Color transparent = Colors.transparent;
  static Color bgDark = const Color.fromRGBO(44, 43, 63, 1); //2C2B3F
  //
  static MaterialColor cyan = Colors.cyan; //0,188,227 //0xFF26C6DA  )
  static Color white = Colors.white.withValues(alpha: 0.975);
  static Color darkGrey = const Color(0xFF9E9E9E);
  static Color red = const Color(0xFFEF5350);

  //
  static Color black = ColorExtension("#232232");
  static Color turqoise = ColorExtension("#00b9bc");
}
