const String documentAssetPath = 'assets/documents';

class DocumentPath {
  static String consultation = '$documentAssetPath/consultation.pdf';
  static String diagnosis = '$documentAssetPath/diagnosis.pdf';
  static String history = '$documentAssetPath/history.pdf';
  static String information = '$documentAssetPath/informationx.pdf';
}
