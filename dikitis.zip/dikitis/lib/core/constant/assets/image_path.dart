const String imageAssetPath = "assets/images";

class ImagePath {
  //image
  static String appLogo = '$imageAssetPath/app_logo.webp';
  static String chat = '$imageAssetPath/onboarding_chat.webp';
  static String observation = '$imageAssetPath/onboarding_observation.webp';
  static String selfDiagnosis = '$imageAssetPath/onboarding_self_diagnosis.webp';
  static String campusLogo = '$imageAssetPath/campus_logo.webp';
  static String dashedArrow = '$imageAssetPath/dashed_arrow.webp';
  static String information = '$imageAssetPath/menu_information.webp';
  static String diagnosis = '$imageAssetPath/menu_diagnosis.webp';
  static String messaging = '$imageAssetPath/menu_messaging.webp';
  static String medicalDoctor = '$imageAssetPath/medical_doctor.webp';
  static String history = '$imageAssetPath/history.webp';
  static String flowBottom = '$imageAssetPath/flow_bottom.webp';
  static String flowTop = '$imageAssetPath/flow_top.webp';
  static String activityHistory = '$imageAssetPath/activity_history.webp';
  static String healthCheckup = '$imageAssetPath/health_checkup.webp';

  //icon
  static const String translate = '$imageAssetPath/translate.webp';
  static const String indonesianFlag = '$imageAssetPath/indonesian.webp';
  static const String englishFlag = '$imageAssetPath/english.webp';
}
