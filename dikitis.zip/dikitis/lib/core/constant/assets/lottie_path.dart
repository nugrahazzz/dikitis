const String lottieAssetPath = "assets/lotties";

class LottiePath {
  static const chat = "$lottieAssetPath/chat.json";
  static const caution = "$lottieAssetPath/caution.json";
  static const noConnection = "$lottieAssetPath/no_connection.json";
  static const exit = "$lottieAssetPath/exit.json";
  static const medicalBag = "$lottieAssetPath/medical_bag.json";
  static const feedback = "$lottieAssetPath/feedback.json";
  static const noData = "$lottieAssetPath/no_data.json";
  static const messages = "$lottieAssetPath/messages.json";
  static const mail = "$lottieAssetPath/mail.json";
  static const checklist = "$lottieAssetPath/checklist.json";
  static const notFound = "$lottieAssetPath/not_found.json";
  static const info = "$lottieAssetPath/info.json";
  static const settings = "$lottieAssetPath/settings.json";
  static const doctor = "$lottieAssetPath/doctor.json";
  static const permission = "$lottieAssetPath/permission.json";
  static const lock = "$lottieAssetPath/lock.json";
  static const search = "$lottieAssetPath/search.json";
  static const searching = "$lottieAssetPath/searching.json";
}
