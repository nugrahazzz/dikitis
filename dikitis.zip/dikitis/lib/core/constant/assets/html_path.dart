const String htmlAssetPath = 'assets/html';

class HtmlPath {
  static String changelogs = '$htmlAssetPath/changelogs.html';
  static String disclaimer = '$htmlAssetPath/disclaimer.html';
  static String privacyPolicy = '$htmlAssetPath/privacy_policy.html';
  static String requiredPermission = '$htmlAssetPath/required_permission.html';
  static String termOfUser = '$htmlAssetPath/term_of_use.html';
}
