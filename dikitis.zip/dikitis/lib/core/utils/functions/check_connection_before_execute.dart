part of 'global_functions.dart';

///check connection before execute some function
void checkConnectionBeforeExecute({required Function() function}) async {
  List<ConnectivityResult> result = await Connectivity().checkConnectivity();

  if (result.contains(ConnectivityResult.none)) {
    Get.dialog(
        const NoConnectionDialog(
            // colorStatusBar: AppColors.transparent,
            // backgroundColor: AppColors.transparent,
            ),
        barrierDismissible: true,
        barrierColor: AppColors.transparent
        // barrierColor: AppColors.bgDark.withValues(alpha: 0.35),
        );
  } else {
    function();
  }
// print(result);
}
