part of 'global_functions.dart';

// void sendNotification({required String title, required String description}) {
//   AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
//     if (!isAllowed) {
//       AwesomeNotifications().requestPermissionToSendNotifications();
//     } else {
//       AwesomeNotifications().createNotification(
//         content:
//             NotificationContent(id: 1, channelKey: 'dikitis_channel', autoDismissible: true, title: title.toString(), body: description.toString()),
//       );
//     }
//   });
// }
