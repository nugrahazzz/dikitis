part of 'global_functions.dart';

///get information device (for bug/crash)
Future<AndroidDeviceInfo> getDeviceInfo() async {
  final AndroidDeviceInfo androidInfo = await DeviceInfoPlugin().androidInfo;
  return androidInfo;
}
