part of 'global_functions.dart';

///showing dialog
void showCustomDialog(
    {String? title,
    String? imagePath,
    String? description,
    String? buttonText,
    Function()? function,
    Color? colorStatusBar,
    Color? colorNavigationBar}) {
  if (Get.isDialogOpen == false) {
    Get.dialog(
        CustomDialog(
          title: title ?? "Keluar",
          imagePath: imagePath ?? LottiePath.exit,
          description: description ?? "Apakah Anda ingin meninggalkan aplikasi ini?",
          buttonText: buttonText ?? "Ya, tentu",
          function: function ??
              () {
                SystemChannels.platform.invokeMethod('SystemNavigator.pop');
              },
          colorStatusBar: colorStatusBar,
          colorNavigationBar: colorNavigationBar,
        ),
        // barrierColor: AppColors.bgDark.withValues(alpha: 0.33));
        barrierColor: AppColors.bgDark.withValues(alpha: 0.5));
  } else {
    Get.closeAllDialogs();
  }
}
