part of 'global_functions.dart';

///translate text to english
final translator = GoogleTranslator();

Future<String> translateText({required String text}) async {
  String textTranslated = "";

  await translator.translate(text, from: 'auto', to: 'en').then((Translation value) {
    textTranslated = value.text;
  });

  return textTranslated;
}
