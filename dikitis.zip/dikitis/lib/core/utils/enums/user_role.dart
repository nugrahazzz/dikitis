enum UserRole {
  patient,
  doctor,
}
