import 'package:dikitis/core/utils/extensions/global_extensions.dart';

class BaseObjectResponse<T> {
  final bool isSuccess;
  final String message;
  final T? data;

  BaseObjectResponse({
    this.isSuccess = false,
    this.message = "",
    this.data,
  });

  factory BaseObjectResponse.fromJson(Map<String, dynamic> json, Function(Map<String, dynamic>) build) => BaseObjectResponse<T>(
        isSuccess: json["is_success"].toString().parseToBool(),
        message: json["message"],
        data: json["data"] != null ? build(json["data"]) : null,
      );
}
