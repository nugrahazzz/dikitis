part of 'global_extensions.dart';

extension DateTimeExtension on DateTime {
  ///formated time
  String get formattedTime => DateFormat('HH:mm').format(this);

  ///formated date
  String get formattedDate => DateFormat('dd/MM/yyyy').format(this);
}
