// import 'package:dikitis/core/utils/enums/user_role.dart';
//
// extension UserRoleExtension on UserRole {
//   String get role {
//     switch (this) {
//       case UserRole.patient:
//         return "patient";
//       case UserRole.doctor:
//         return "doctor";
//       default:
//         return "patient";
//     }
//   }
// }
