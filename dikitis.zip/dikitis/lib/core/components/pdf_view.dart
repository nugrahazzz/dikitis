part of 'global_components.dart';

class PDFView extends StatelessWidget {
  final String path;

  const PDFView({super.key, required this.path});

  @override
  Widget build(BuildContext context) {
    changeBarColor(statusBarColor: AppColors.white, navBarColor: AppColors.white);
    return BackButtonListener(
      onBackButtonPressed: () {
        Get.back();
        changeBarColor(statusBarColor: AppColors.bgDark, navBarColor: AppColors.bgDark);

        return Future<bool>.value(true);
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Stack(
            children: [
              PdfViewer.asset(
                path,
                params: const PdfViewerParams(panEnabled: true, scaleEnabled: false), // show the page-2
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1200),
                animationDuration: const Duration(seconds: 1),
                animation: DelayedAnimations.SLIDE_FROM_BOTTOM,
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: GestureDetector(
                    onTap: () {
                      Get.back();
                      changeBarColor(statusBarColor: AppColors.bgDark, navBarColor: AppColors.bgDark);
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 7.5.wp),
                      padding: EdgeInsets.all(3.0.wp),
                      // height: 15.0.wp,
                      decoration: BoxDecoration(color: AppColors.bgDark.withValues(alpha: 0.9), shape: BoxShape.circle),
                      child: Icon(
                        Icons.close_sharp,
                        color: AppColors.white,
                        size: 9.0.wp,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
