part of 'global_components.dart';

class NoConnectionDialog extends StatefulWidget {
  // final Color? colorStatusBar;
  // final Color? backgroundColor;

  const NoConnectionDialog({
    super.key,
    // this.colorStatusBar = Colors.transparent,
    // this.backgroundColor = Colors.cyan,
  });

  @override
  State<NoConnectionDialog> createState() => _NoConnectionDialogState();
}

class _NoConnectionDialogState extends State<NoConnectionDialog> {
  @override
  void initState() {
    super.initState();
    // changeBarColor(
    //   statusBarColor: widget.colorStatusBar!,
    //   navBarColor: widget.backgroundColor ?? Colors.cyan[700]!,
    // );
  }

  @override
  Widget build(BuildContext context) {
    return BackButtonListener(
      onBackButtonPressed: () {
        Get.backLegacy();
        return Future<bool>.value(true);
      },
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: GestureDetector(
            onTap: () {
              Get.backLegacy();
              // changeBarColor(
              //   statusBarColor: Colors.transparent,
              //   navBarColor: widget.backgroundColor ?? Colors.cyan[700]!,
              // );
            },
            child: Container(
              height: Get.height,
              width: Get.width,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppColors.transparent,
                    AppColors.bgDark.withValues(alpha: 0.25),
                    AppColors.bgDark.withValues(alpha: 0.5),
                    AppColors.bgDark.withValues(alpha: 0.5),
                    AppColors.bgDark.withValues(alpha: 0.25),
                    AppColors.transparent,
                  ],
                ),
              ),
              child: Center(
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 12.5.wp),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Container(
                          margin: EdgeInsets.all(1.0.wp),
                          padding: EdgeInsets.all(1.0.wp),
                          decoration: BoxDecoration(
                            color: AppColors.bgDark,
                            borderRadius: const BorderRadius.all(Radius.circular(16)),
                          ),
                          child: Lottie.asset(
                            LottiePath.noConnection,
                            fit: BoxFit.cover,
                            addRepaintBoundary: false,
                            filterQuality: FilterQuality.low,
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(
                          top: 6.0.wp,
                          bottom: 7.0.wp,
                          right: 6.0.wp,
                          left: 6.0.wp,
                        ),
                        child: Text(
                          "noInternetAccess".tr,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.bgDark.withValues(alpha: 0.8),
                            fontSize: 4.2.wp,
                            letterSpacing: 0.8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
