part of 'global_components.dart';

class CustomTextField extends StatefulWidget {
  final bool? visibility;
  final bool? enabled;
  final double? height;
  final String? hintText;
  final IconData? icon;
  final IconData? iconSuffix;

  final ValueChanged<String>? onChanged;
  final TextEditingController? controller;
  final bool? useSuffixIcon;
  final Function()? function;
  final FocusNode? currentNode;
  final FocusNode? nextNode;
  final double? borderRadius;
  final List<TextInputFormatter>? filteringTextInputFormatter;
  final TextCapitalization? textCapitalization;
  final Color? colorHint;
  final Color? colorIcon;

  const CustomTextField({
    super.key,
    required this.hintText,
    this.icon = Icons.person,
    this.onChanged,
    this.controller,
    this.visibility = false,
    this.useSuffixIcon = false,
    this.function,
    this.height,
    required this.currentNode,
    required this.nextNode,
    this.borderRadius = 12,
    this.filteringTextInputFormatter,
    this.textCapitalization,
    this.enabled = true,
    this.iconSuffix = Icons.edit,
    this.colorHint = Colors.black45,
    this.colorIcon = Colors.cyan,
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  FocusNode? _focusNode;

  @override
  void initState() {
    super.initState();
    if (widget.nextNode != null) {
      _focusNode = widget.nextNode;
    } else {
      _focusNode = FocusNode();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: (widget.height == null) ? 19.0.wp : widget.height,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 2.0.wp),
        padding: EdgeInsets.symmetric(horizontal: 4.0.wp),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(widget.borderRadius!),
        ),
        child: Container(
          alignment: Alignment.center,
          child: TextFormField(
            enabled: widget.enabled,
            autocorrect: false,
            enableSuggestions: widget.visibility != true ? true : false,
            enableIMEPersonalizedLearning: widget.visibility != true ? true : false,
            enableInteractiveSelection: widget.visibility != true ? true : false,
            textAlignVertical: widget.useSuffixIcon! ? TextAlignVertical.center : TextAlignVertical.top,
            textCapitalization: widget.textCapitalization ?? TextCapitalization.none,
            inputFormatters: widget.filteringTextInputFormatter ?? [],
            style: AppTextStyles.poppinsSemiBold.copyWith(
                color: AppColors.bgDark.withValues(alpha: 0.9),
                fontFamily: AppTextStyles.medium,
                fontWeight: FontWeight.w300,
                letterSpacing: 0.1,
                wordSpacing: 0.2,
                fontSize: 3.8.wp),
            obscureText: widget.visibility!,
            focusNode: widget.currentNode,
            onFieldSubmitted: (term) {
              changeFieldFocus(context, widget.currentNode!, _focusNode!);
            },
            controller: widget.controller,
            onChanged: widget.onChanged,
            textInputAction: (widget.nextNode == null) ? TextInputAction.done : TextInputAction.next,
            cursorColor: AppColors.cyan,
            decoration: InputDecoration(
              hintText: widget.hintText,
              border: InputBorder.none,
              hintStyle: TextStyle(color: widget.colorHint),
              icon: Icon(
                widget.icon,
                color: AppColors.cyan,
              ),
              suffixIcon: (widget.useSuffixIcon == true)
                  ? GestureDetector(
                      onTap: widget.function,
                      child: SizedBox(
                        child: Padding(
                          padding: EdgeInsets.only(left: 4.0.wp),
                          child: Icon(
                            (widget.iconSuffix != null)
                                ? widget.iconSuffix
                                : (widget.visibility == true)
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                            color: widget.colorIcon,
                          ),
                        ),
                      ),
                    )
                  : null,
            ),
          ),
        ),
      ),
    );
  }
}
