part of 'global_components.dart';

class CustomDialog extends StatefulWidget {
  final String? title, description, buttonText;
  final String? imagePath;
  final Function()? function;
  final Color? colorStatusBar;
  final Color? colorNavigationBar;

  const CustomDialog({
    super.key,
    this.title = "",
    this.description = "",
    this.buttonText = "",
    this.imagePath = "",
    this.function,
    this.colorStatusBar = Colors.transparent,
    this.colorNavigationBar = Colors.transparent,
  });

  @override
  CustomDialogState createState() => CustomDialogState();
}

class CustomDialogState extends State<CustomDialog> {
  double padding = 5.0.wp;
  double avatarRadius = 15.0.wp;

  @override
  void initState() {
    super.initState();
    changeBarColor(
      statusBarColor: widget.colorStatusBar!,
      navBarColor: widget.colorNavigationBar!,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      backgroundColor: AppColors.transparent,
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(
              // top: avatarRadius + padding / 2,
              top: avatarRadius,
              left: padding,
              right: padding,
            ),
            margin: EdgeInsets.only(top: avatarRadius),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(padding),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 10.0,
                  offset: Offset(0.0, 10.0),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min, // To make the card compact
              children: <Widget>[
                Text(
                  widget.title!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 6.0.wp,
                    fontWeight: FontWeight.w900,
                    color: AppColors.bgDark.withValues(alpha: 0.9),
                  ),
                ),
                SizedBox(height: 2.0.wp),
                Container(
                  color: AppColors.transparent,
                  padding: EdgeInsets.symmetric(horizontal: 3.3.wp),
                  child: Text(
                    widget.description!,
                    textAlign: TextAlign.center,
                    style: AppTextStyles.poppinsSemiBold
                        .copyWith(color: AppColors.bgDark.withValues(alpha: 0.7), fontSize: 3.4.wp, letterSpacing: 0.3, wordSpacing: 1),
                  ),
                ),
                SizedBox(height: 6.0.wp),
                //ya
                CustomButton(
                    onlyIcon: false,
                    width: 65.0.wp,
                    borderRadius: 16,
                    height: 14.0.wp,
                    color: AppColors.cyan.withValues(alpha: 0.75),
                    borderColor: AppColors.cyan,
                    title: widget.buttonText,
                    titleColor: AppColors.white,
                    function: () {
                      Navigator.pop(context, true);
                      widget.function!();
                    }),
                //tidak
                // SizedBox(height: 4.0.wp),
                // CustomButton(
                //     onlyIcon: false,
                //     width: 60.0.wp,
                //     borderRadius: 16,
                //     height: 14.0.wp,
                //     color: AppColors.bgDark.withValues(alpha: 0.05),
                //     borderColor: AppColors.bgDark,
                //     title: "Close",
                //     titleColor: AppColors.bgDark,
                //     function: () {
                //       Navigator.pop(context, true);
                //       widget.function!();
                //     }),
                SizedBox(height: 8.0.wp),

                // GestureDetector(
                //   onTap: () {
                //     Navigator.pop(context, true);
                //   },
                //   child: Container(
                //     margin: EdgeInsets.only(top: 1.0.wp, bottom: 2.0.wp),
                //     color: AppColors.transparent,
                //     height: 5.0.hp,
                //     child: Center(
                //       child: Text(
                //         //No, thanks
                //         "Tidak, terima kasih",
                //         style: AppTextStyles.poppinsSemiBold.copyWith(
                //           fontSize: 3.4.wp,
                //           fontWeight: FontWeight.bold,
                //           color: AppColors.darkGrey,
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
          //Gambar
          Positioned.fill(
            child: Align(
              alignment: Alignment.topCenter,
              child: Container(
                height: 30.0.wp,
                width: 30.0.wp,
                decoration: BoxDecoration(
                  color: Colors.white, // Warna latar belakang
                  shape: BoxShape.circle, // Membuat bentuk lingkaran
                ),
                child: Padding(
                  padding: EdgeInsets.all(3.0.wp),
                  child: Lottie.asset(
                    widget.imagePath!,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
