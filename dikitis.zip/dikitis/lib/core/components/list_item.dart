part of 'global_components.dart';

class ListItem extends StatelessWidget {
  final IconData icon;
  final bool isNavigate;
  final String text;
  final Function()? function;

  const ListItem({super.key, this.icon = Icons.error, this.text = "", this.function, this.isNavigate = true});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: function,
      child: Container(
        // height: 16.0.wp,
        margin: EdgeInsets.only(
          bottom: 5.0.wp,
        ),
        padding: EdgeInsets.symmetric(horizontal: 4.0.wp, vertical: 4.0.wp),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: AppColors.white,
        ),
        child: Row(
          children: <Widget>[
            (icon != Icons.minimize_rounded)
                ? Icon(
                    icon,
                    size: 7.0.wp,
                    color: AppColors.bgDark,
                  )
                : const SizedBox(),
            (icon != Icons.minimize_rounded) ? SizedBox(width: 4.0.wp) : const SizedBox(),
            Expanded(
                child: Text(
              text,
              style: AppTextStyles.poppinsMedium.copyWith(
                color: AppColors.bgDark.withValues(alpha: 0.85),
                fontSize: 3.25.wp,
                wordSpacing: 0.3,
              ),
            )),
            (isNavigate)
                ? Padding(
                    padding: EdgeInsets.only(left: 4.0.wp),
                    child: Icon(
                      Icons.chevron_right_sharp,
                      size: 6.0.wp,
                    ),
                  )
                : Padding(
                    padding: EdgeInsets.only(right: 2.0.wp),
                    child: Icon(
                      Icons.circle_rounded,
                      size: 1.5.wp,
                    ),
                  )
          ],
        ),
      ),
    );
  }
}
