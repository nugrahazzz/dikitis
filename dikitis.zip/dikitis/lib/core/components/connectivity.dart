// import 'package:connectivity_widget/connectivity_widget.dart';
// import 'package:flutter/material.dart';
//
// class Connectivity extends StatelessWidget {
//   final Widget isOnline;
//   final Widget isOffline;
//   final Function()? onlineCallback;
//
//   const Connectivity({
//     super.key,
//     required this.isOnline,
//     required this.isOffline,
//     this.onlineCallback,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return ConnectivityWidget(
//       onlineCallback: onlineCallback,
//       showOfflineBanner: false,
//       initialLoadingWidget: const SizedBox.shrink(),
//       builder: (context, checkIsOnline) => (checkIsOnline) ? isOnline : isOffline,
//     );
//   }
// }
