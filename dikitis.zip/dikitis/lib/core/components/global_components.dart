import 'package:auto_size_text/auto_size_text.dart';
import 'package:bounce/bounce.dart';
import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_html_reborn/flutter_html_reborn.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:lottie/lottie.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:get/get.dart';

part 'custom_button.dart';

part 'custom_card_animation.dart';

part 'custom_dialog.dart';

part 'custom_empty.dart';

part 'custom_error.dart';

part 'custom_loading.dart';

part 'custom_text_field.dart';

part 'html_view.dart';

part 'list_item.dart';

part 'no_connection_dialog.dart';

part 'pdf_view.dart';
