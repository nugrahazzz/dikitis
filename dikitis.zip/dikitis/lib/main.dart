// import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:dikitis/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_storage/get_storage.dart';

void main() async {
  await initialize();
  runApp(const App());
}

Future<void> initialize() async {
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  //
  // AwesomeNotifications().initialize(
  //     null,
  //     [
  //       NotificationChannel(
  //         channelGroupKey: 'dikitis_channel_group',
  //         channelKey: 'dikitis_channel',
  //         channelName: 'Dikitis Notification',
  //         channelDescription: 'Notifications for basic testing',
  //         defaultColor: AppColors.cyan,
  //         ledColor: AppColors.white,
  //       )
  //     ],
  //     channelGroups: [
  //       NotificationChannelGroup(
  //         channelGroupKey: 'dikitis_channel_group',
  //         channelGroupName: 'Dikitis Group Notification',
  //       ),
  //     ],
  //     debug: true);
}
