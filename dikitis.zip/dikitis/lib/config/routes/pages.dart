import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/features/about/presentation/pages/about_page.dart';
import 'package:dikitis/features/attribution/presentation/pages/atribution_page.dart';
import 'package:dikitis/features/authentication/presentation/bindings/authentication_binding.dart';
import 'package:dikitis/features/authentication/presentation/pages/authentication_page.dart';
import 'package:dikitis/features/change_language/presentation/bindings/change_language_binding.dart';
import 'package:dikitis/features/change_language/presentation/views/change_language_view.dart';
import 'package:dikitis/features/credit/presentation/pages/credit_page.dart';
import 'package:dikitis/features/email_verification/presentation/bindings/verification_binding.dart';
import 'package:dikitis/features/email_verification/presentation/pages/verification_page.dart';
import 'package:dikitis/features/feature_introduction/presentation/pages/feature_introduction.dart';
import 'package:dikitis/features/home_page/binding/home_binding.dart';
import 'package:dikitis/features/home_page/pages/main_page.dart';
import 'package:dikitis/features/information/presentation/binding/information_binding.dart';
import 'package:dikitis/features/information/presentation/pages/information_page.dart';
import 'package:dikitis/features/legal_note/presentation/bindings/legal_note_binding.dart';
import 'package:dikitis/features/legal_note/presentation/views/legal_note_page.dart';
import 'package:dikitis/features/onboarding/presentation/bindings/onboarding_binding.dart';
import 'package:dikitis/features/onboarding/presentation/views/onboarding_page.dart';
import 'package:dikitis/features/splash/presentation/bindings/splash_binding.dart';
import 'package:dikitis/features/splash/presentation/views/splash_page.dart';
import 'package:get/get.dart';

class Pages {
  static final List<GetPage> getPages = [
    GetPage(
      name: Routes.splashPage,
      page: () => const SplashPage(),
      bindings: [
        ChangeLanguageBinding(),
        SplashBinding(),
      ],
    ),
    GetPage(
      name: Routes.authenticationPage,
      page: () => const AuthenticationPage(),
      binding: AuthenticationBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.emailVerificationPage,
      page: () => const VerificationPage(),
      binding: VerificationBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.onboardingPage,
      page: () => const OnboardingPage(),
      binding: OnboardingBinding(),
      // middlewares: [OnboardingMiddleware()],
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.homePage,
      page: () => const HomePage(),
      binding: HomeBinding(),
      transition: Transition.cupertinoDialog,
      transitionDuration: const Duration(milliseconds: 125),
    ),
    // GetPage(
    //   name: Routes.editProfilePage,
    //   page: () => const EditProfilePage(),
    //   transition: Transition.fadeIn,
    //   binding: EditProfileBinding(),
    // ),

    // GetPage(
    //   name: Routes.permissionPage,
    //   page: () => const PermissionPage(),
    //   binding: PermissionBinding(),
    // ),
    // GetPage(
    //   name: Routes.diagnosisHistoryPage,
    //   page: () => const DiagnosisHistoryPage(),
    //   binding: DiagnosticReportBinding(),
    //   transition: Transition.downToUp,
    //   transitionDuration: const Duration(milliseconds: 500),
    // ),

    // GetPage(
    //     name: Routes.diagnosisResultPage,
    //     binding: DiagnosisBinding(),
    //     page: () => const DiagnosisResultPage(),
    //     transition: Transition.downToUp,
    //     transitionDuration: const Duration(milliseconds: 400)),
    // GetPage(
    //   name: Routes.pinCodeScreen,
    //   page: () => PinCodeScreen(),
    // ),
    GetPage(
      binding: ChangeLanguageBinding(),
      name: Routes.selectLanguagePage,
      page: () => const ChangeLanguagePage(),
      transition: Transition.fadeIn,
    ),
    // GetPage(
    //   name: Routes.settingPage,
    //   page: () => const SettingPage(),
    //   transition: Transition.fadeIn,
    //   showCupertinoParallax: false,
    //   preventDuplicates: false,
    //   // curve: Curves.decelerate,
    //   opaque: false,
    // ),
    // GetPage(
    //   name: Routes.imageUploadScreen,
    //   page: () => const ImageUploadScreen(),
    // ),
    // GetPage(
    //   name: Routes.feedbackPage,
    //   page: () => const FeedbackPage(),
    //   binding: FeedbackBinding(),
    //   transition: Transition.noTransition,
    // ),
    // GetPage(
    //   name: Routes.diagnosisPage,
    //   page: () => const DiagnosisPage(),
    //   binding: DiagnosisBinding(),
    // ),
    GetPage(
      name: Routes.informationPage,
      page: () => const InformationPage(),
      binding: InformationBinding(),
      transition: Transition.fadeIn,
    ),

    // GetPage(
    //   name: Routes.doctorAvailablePage,
    //   // parameters: data,
    //   page: () => const DoctorAvailablePage(),
    //   binding: MessageBinding(),
    //   transition: Transition.fadeIn,
    // ),

    GetPage(
      name: Routes.attributionPage,
      page: () => const AttributionPage(),
      transition: Transition.fadeIn,
    ),
    // GetPage(
    //   name: Routes.changePasswordPage,
    //   page: () => const ChangePasswordPage(),
    //   binding: ChangePasswordBinding(),
    //   transition: Transition.fadeIn,
    //   // binding: SplashBinding(),
    // ),
    // GetPage(
    //   name: Routes.themePage,
    //   page: () => const ThemePage(),
    //   transition: Transition.fadeIn,
    //   binding: ThemeBinding(),
    // ),

    GetPage(
      name: Routes.legalNote,
      page: () => const LegalNotePage(),
      binding: LegalNoteBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.aboutPage,
      page: () => const AboutPage(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.creditPage,
      page: () => const CreditPage(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: Routes.featureIntroductionPage,
      page: () => const FeatureIntroductionPage(),
      transition: Transition.noTransition,
    ),
  ];
}
