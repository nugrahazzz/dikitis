class Routes {
  static const splashPage = '/splashPage';
  static const authenticationPage = '/authPage';
  static const onboardingPage = '/onboardingPage';
  static const homePage = '/homePage';
  static const editProfilePage = '/editProfilePage';
  static const notificationPage = '/notificationPage';
  static const permissionPage = '/permissionPage';
  static const permissionDialog = '/permissionDialog';
  static const selectLanguagePage = '/selectLanguagePage';
  static const settingPage = '/settingPage';
  static const feedbackPage = '/feedbackPage';
  static const diagnosisPage = '/diagnosisPage';
  static const diagnosisResultPage = '/diagnosisResultPage';
  static const diagnosisHistoryPage = '/diagnosisHistoryPage';
  static const doctorAvailablePage = '/doctorAvailableScreen';
  static const informationPage = '/informationPage';
  static const emailVerificationPage = '/emailVerificationPage';
  static const attributionPage = '/attributionPage';
  static const changePasswordPage = '/changePasswordPage';
  static const themePage = '/themePage';
  static const legalNote = '/legalNotePage';
  static const aboutPage = '/aboutPage';
  static const creditPage = '/creditPage';
  static const featureIntroductionPage = '/introduceTutorialPage';
}
