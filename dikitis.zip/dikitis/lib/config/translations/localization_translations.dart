import 'package:dikitis/config/translations/en_translation.dart';
import 'package:dikitis/config/translations/id_translation.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LocalizationTranslations extends Translations {
  // Default Locales
  static const Locale idLocale = Locale('id', 'ID');
  static const Locale engLocale = Locale('en', 'US');

  // Language options
  static const List<Locale> locale = [idLocale, engLocale];

  static const List<String> langs = ["Indonesian", "English"];
  static const List<String> iconLangs = [
    ImagePath.indonesianFlag,
    ImagePath.englishFlag,
  ];

  // Supported locales
  static const List<Locale> locales = [idLocale, engLocale];

  /// Change application locale based on selected language
  static void changeLocale({required Locale locale}) {
    final dataLocale = locale;
    Get.updateLocale(dataLocale);
  }

  @override
  Map<String, Map<String, String>> get keys => {
        'id_ID': id, // Indonesian translations
        'en_US': en, // English translations
      };
}
