import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/html_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  AboutPageState createState() => AboutPageState();
}

class AboutPageState extends State<AboutPage> {
  @override
  void initState() {
    super.initState();
    changeBarColor(statusBarColor: Colors.transparent, navBarColor: AppColors.bgDark);
  }

  @override
  Widget build(BuildContext context) {
    return BackButtonListener(
      onBackButtonPressed: () {
        Get.back();
        Future.delayed(const Duration(milliseconds: 400), () {
          changeBarColor(statusBarColor: Colors.transparent, navBarColor: AppColors.bgDark);
        });

        return Future<bool>.value(true);
      },
      child: Scaffold(
        backgroundColor: AppColors.bgDark,
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 6.0.wp).copyWith(top: 11.0.wp),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(bottom: 5.0.wp),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Divider(
                          height: 2,
                          color: AppColors.white,
                        ),
                      ),
                      Expanded(
                        flex: 5,
                        child: Center(
                          child: Text(
                            "Application",
                            style: AppTextStyles.poppinsBold.copyWith(color: AppColors.white, fontSize: 6.0.wp),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Divider(
                          height: 2,
                          color: AppColors.white,
                        ),
                      ),
                    ],
                  ),
                ),

                //Versi
                ListItem(
                  isNavigate: true,
                  function: () {
                    Get.toNamed(Routes.legalNote, arguments: HtmlPath.changelogs);
                  },
                  icon: Icons.adb_rounded,
                  text: "Ver 1.1.0 (Changelog)",
                ),

                //Credit
                ListItem(
                  function: () {
                    Get.toNamed(Routes.creditPage);
                  },
                  icon: Icons.copyright_rounded,
                  text: "Credits",
                ),

                Padding(
                  padding: EdgeInsets.only(bottom: 5.0.wp),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Divider(
                          height: 2,
                          color: AppColors.white,
                        ),
                      ),
                      Expanded(
                        flex: 4,
                        child: Center(
                          child: Text(
                            "Legal Note",
                            style: AppTextStyles.poppinsBold.copyWith(color: AppColors.white, fontSize: 6.0.wp),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Divider(
                          height: 2,
                          color: AppColors.white,
                        ),
                      ),
                    ],
                  ),
                ),

                //Disclaimer
                ListItem(
                  function: () {
                    Get.toNamed(Routes.legalNote, arguments: HtmlPath.disclaimer);
                  },
                  icon: Icons.campaign_outlined,
                  text: "Disclaimer",
                ),

                //Privacy Policy
                ListItem(
                  function: () {
                    Get.toNamed(Routes.legalNote, arguments: HtmlPath.requiredPermission);
                  },
                  icon: Icons.perm_device_info,
                  text: "Required Permission",
                ),

                //Privacy Policy
                ListItem(
                  function: () {
                    Get.toNamed(Routes.legalNote, arguments: HtmlPath.privacyPolicy);
                  },
                  icon: Icons.privacy_tip_outlined,
                  text: "Privacy Policy",
                ),

                //TOS
                ListItem(
                  function: () {
                    Get.toNamed(Routes.legalNote, arguments: HtmlPath.termOfUser);
                  },
                  icon: Icons.toc,
                  text: "Term of Use",
                ),

                //Atributtion
                ListItem(
                  function: () {
                    Get.toNamed(
                      Routes.attributionPage,
                    );
                  },
                  icon: Icons.drive_file_rename_outline_rounded,
                  text: "Open Source Software Attributions",
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
