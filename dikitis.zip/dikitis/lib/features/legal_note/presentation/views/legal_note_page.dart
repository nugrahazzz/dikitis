import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/html_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_html_reborn/flutter_html_reborn.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';

import '../controllers/legal_note_controller.dart';

class LegalNotePage extends StatefulWidget {
  const LegalNotePage({super.key});

  @override
  State<LegalNotePage> createState() => _LegalNotePageState();
}

class _LegalNotePageState extends State<LegalNotePage> {
  final LegalNoteController controller = LegalNoteController.to;

  Future<String> loadAsset(BuildContext context, String textAsset) async {
    String text = await rootBundle.loadString(textAsset);
    return text;
  }

  @override
  void initState() {
    super.initState();
    controller.isScrollToBottom.value = false;
    changeBarColor(
      statusBarColor: AppColors.transparent,
      navBarColor: AppColors.bgDark,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: SafeArea(
        child: Stack(
          children: [
            FutureBuilder<String>(
                //privacy_policy or disclaimer
                future: loadAsset(context, Get.arguments ?? HtmlPath.requiredPermission),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      controller: controller.listScrollController,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 3.0.wp).copyWith(top: 1.0.wp, bottom: 20.0.wp),
                        child: Html(
                          data: snapshot.data.toString(),
                          style: {
                            "img": Style(width: Width(50.0.wp), alignment: Alignment.center),
                            "div": Style(
                              color: AppColors.white,
                              fontFamily: AppTextStyles.medium,
                              fontSize: FontSize(3.2.wp),
                              letterSpacing: 0.5,
                              padding: HtmlPaddings.zero,
                              // EdgeInsets.zero
                            ),
                            "h1": Style(
                              color: AppColors.white,
                              fontFamily: AppTextStyles.medium,
                              fontSize: FontSize(5.5.wp),
                              letterSpacing: 0.5,
                              padding: HtmlPaddings.only(top: 2.5.wp, bottom: 0),
                              // EdgeInsets.only(top: 2.5.wp, bottom: 0),
                            ),
                            "h2": Style(
                                color: AppColors.white,
                                fontFamily: AppTextStyles.medium,
                                fontSize: FontSize(4.3.wp),
                                letterSpacing: 0.5,
                                padding: HtmlPaddings.only(top: 2.5.wp)
                                // EdgeInsets.only(top: 2.5.wp),
                                ),
                            "h3": Style(
                                color: AppColors.white,
                                fontFamily: AppTextStyles.medium,
                                fontSize: FontSize(3.6.wp),
                                letterSpacing: 0.5,
                                padding: HtmlPaddings.only(top: 1.25.wp)
                                // EdgeInsets.only(top: 1.25.wp),
                                ),
                            "h4": Style(
                                color: AppColors.white.withValues(alpha: 0.95),
                                fontFamily: AppTextStyles.medium,
                                fontSize: FontSize(3.5.wp),
                                wordSpacing: 0.5,
                                letterSpacing: 0.5),
                            "p": Style(
                                color: AppColors.white,
                                fontFamily: AppTextStyles.medium,
                                textAlign: TextAlign.justify,
                                wordSpacing: 0.25,
                                letterSpacing: 0.25),
                            "mark": Style(
                                fontFamily: AppTextStyles.medium,
                                fontSize: FontSize(3.5.wp),
                                wordSpacing: 0.5,
                                letterSpacing: 0.5,
                                backgroundColor: AppColors.bgDark),
                            "ol": Style(color: AppColors.white, fontFamily: AppTextStyles.medium),
                            "ul": Style(color: AppColors.white, fontFamily: AppTextStyles.medium),
                            "li": Style(color: AppColors.white, fontFamily: AppTextStyles.medium),
                            "hr": Style(color: AppColors.white, padding: HtmlPaddings.zero),
                          },
                        ),
                      ),
                    );
                  } else {
                    return SizedBox(
                      height: 14.0.wp,
                      child: Center(
                        child: SpinKitWave(
                          color: AppColors.white,
                          size: 6.0.wp,
                        ),
                      ),
                    );
                  }
                }),
            DelayedWidget(
              delayDuration: const Duration(milliseconds: 1500),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: SizedBox(
                  height: 20.0.wp,
                  child: Center(
                    child: Container(
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(20)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 3.0,
                            offset: Offset(0.0, 10.0),
                          ),
                        ],
                      ),
                      child: Obx(
                        () => CustomButton(
                          borderRadius: 4.0.wp,
                          color: AppColors.cyan,
                          titleColor: AppColors.bgDark,
                          height: 12.0.wp,
                          width: 65.0.wp,
                          title: (controller.isScrollToBottom.value == false) ? "Scroll to bottom" : "Go Back",
                          function: () {
                            controller.scrollToBottom();
                          },
                          onlyIcon: false,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
