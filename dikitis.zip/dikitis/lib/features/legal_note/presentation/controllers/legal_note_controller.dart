import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LegalNoteController extends GetxController {
  static final LegalNoteController to = Get.find<LegalNoteController>();

  late ScrollController listScrollController;
  RxBool isScrollToBottom = false.obs;

  @override
  onInit() {
    super.onInit();
    listScrollController = ScrollController();
  }

  void scrollToBottom() {
    if (isScrollToBottom.value == false) {
      if (listScrollController.hasClients) {
        final position = listScrollController.position.maxScrollExtent;
        listScrollController
            .animateTo(
              position,
              duration: const Duration(seconds: 2),
              curve: Curves.easeOut,
            )
            .then((value) => isScrollToBottom.value = true);
      }
    } else {
      Future.delayed(const Duration(milliseconds: 750), () {
        isScrollToBottom.value = false;
      });
      Get.back();
    }
  }
}
