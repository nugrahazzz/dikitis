import 'package:get/get.dart';

import '../controllers/legal_note_controller.dart';

class LegalNoteBinding extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<LegalNoteController>(() => LegalNoteController()),
    ];
  }
}
