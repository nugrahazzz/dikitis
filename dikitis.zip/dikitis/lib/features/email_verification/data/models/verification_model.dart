import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';

class VerificationModel extends VerificationEntity {
  const VerificationModel({
    super.id,
    required super.email,
    super.codeVerification,
  });

  factory VerificationModel.fromJson(Map<String, dynamic> json) => VerificationModel(
        id: json["verification_id"].toString(),
        email: json["user_email"].toString(),
        codeVerification: json["verification_code"].toString(),
      );

  VerificationEntity toEntity() {
    return VerificationEntity(
      id: id,
      email: email,
      codeVerification: codeVerification,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'verification_id': id,
      'user_email': email,
      'verification_code': codeVerification,
    };
  }
}
