import 'package:dikitis/core/constant/api/api_path.dart';
import 'package:dikitis/core/services/rest_api_service.dart';
import 'package:dikitis/core/utils/helper/base_object_response.dart';
import 'package:dikitis/features/email_verification/data/models/verification_model.dart';
import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';
import 'package:dio/dio.dart';

abstract class VerificationRemoteDataSource {
  Future<BaseObjectResponse<VerificationModel>> createVerificationCode(VerificationEntity verification);

  Future<BaseObjectResponse<VerificationModel>> checkVerificationCode(VerificationEntity verification);
}

class VerificationRemoteDataSourceImpl implements VerificationRemoteDataSource {
  final RestApiService apiService;

  VerificationRemoteDataSourceImpl({
    required this.apiService,
  });

  @override
  Future<BaseObjectResponse<VerificationModel>> createVerificationCode(VerificationEntity verification) async {
    final dataVerification = VerificationModel(
      id: verification.id,
      email: verification.email,
      codeVerification: verification.codeVerification,
    ).toJson();

    // API call
    final response = await apiService.post(
      endPoint: ApiPath.createCodeVerification,
      data: dataVerification,
    );

    return _processResponse(response);
  }

  @override
  Future<BaseObjectResponse<VerificationModel>> checkVerificationCode(VerificationEntity verification) async {
    final dataVerification = VerificationModel(
      email: verification.email,
      codeVerification: verification.codeVerification,
    ).toJson();

    // API call
    final response = await apiService.post(
      endPoint: ApiPath.checkCodeVerification,
      data: dataVerification,
    );

    return _processResponse(response);
  }

  Future<BaseObjectResponse<VerificationModel>> _processResponse(Response<dynamic> response) async {
    final parsedResponse = BaseObjectResponse<VerificationModel>.fromJson(
      response.data,
      (json) => VerificationModel.fromJson(json),
    );

    if (parsedResponse.isSuccess) {
      return parsedResponse;
    } else {
      throw parsedResponse.message; // Pastikan `throw` melempar Exception
    }
  }
}
