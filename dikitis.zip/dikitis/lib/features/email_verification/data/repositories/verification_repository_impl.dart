import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/base_object_response.dart';
import 'package:dikitis/features/email_verification/data/data_source/verification_remote_data_source.dart';
import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';
import 'package:dikitis/features/email_verification/domain/repositories/verification_repository.dart';

class VerificationRepositoryImpl implements VerificationRepository {
  final VerificationRemoteDataSource remoteDataSource;

  VerificationRepositoryImpl({
    required this.remoteDataSource,
  });

  @override
  Future<Either<Failure, BaseObjectResponse>> checkVerificationCode(VerificationEntity verification) async {
    try {
      final result = await remoteDataSource.checkVerificationCode(verification);
      return Right(result);
    } catch (error) {
      return Left(ErrorHandler.handle(error).failure);
    }
  }

  @override
  Future<Either<Failure, BaseObjectResponse>> createVerificationCode(VerificationEntity verification) async {
    try {
      final result = await remoteDataSource.createVerificationCode(verification);
      return Right(result);
    } catch (error) {
      return Left(ErrorHandler.handle(error).failure);
    }
  }
}
