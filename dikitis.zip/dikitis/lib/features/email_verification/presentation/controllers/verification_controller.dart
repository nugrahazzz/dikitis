import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';
import 'package:dikitis/features/email_verification/domain/usecases/check_verification_code.dart';
import 'package:dikitis/features/email_verification/domain/usecases/create_verification_code.dart';
import 'package:get/get.dart';

class VerificationController extends GetxController {
  final CreateVerificationCodeUseCase createVerificationCodeUseCase;
  final CheckVerificationCodeUseCase checkVerificationCodeUseCase;

  VerificationController({
    required this.checkVerificationCodeUseCase,
    required this.createVerificationCodeUseCase,
  });

  RxBool isResendCodeVisible = true.obs;

  @override
  void onInit() {
    super.onInit();
    isResendCodeVisible(true);
    createVerificationCodeC(email: Get.arguments['email'].toString());
  }

  void createVerificationCodeC({required String email}) async {
    if (email.isNotEmpty) {
      VerificationEntity verification = VerificationEntity(
        email: email,
      );

      final Either<Failure, void> results = await createVerificationCodeUseCase(Params(verification));

      results.fold((Failure failure) {
        showErrorSnackbar(failure);
      }, (data) {
        showCustomSnackBar(title: "sendingCode".tr, description: "checkEmail".tr);
      });
    } else {
      showCustomSnackBar(title: "emailNull".tr, description: "fieldNull".tr);
    }
  }

  void resentVerificationCodeC({required String email}) {
    isResendCodeVisible(false);
    createVerificationCodeC(email: email);
    // showCustomSnackBar(title: "resendCodeDialog".tr, description: "resendCodeDialogDesc".tr);
  }

  void checkVerificationCodeC({required int inputCode, required String email}) async {
    VerificationEntity verification = VerificationEntity(
      email: email,
      codeVerification: inputCode.toString(),
    );
    //memverifikasi user berdasarkan email
    final Either<Failure, void> results = await checkVerificationCodeUseCase(Params(verification));

    results.fold((Failure failure) {
      showCustomSnackBar(title: failure.message, description: "(Error code: ${failure.code})");
    }, (response) async {
      Get.back();
      showCustomSnackBar(title: "Berhasil memverifikasi email", description: "Silahkan melakukan login");
    });
  }
}
