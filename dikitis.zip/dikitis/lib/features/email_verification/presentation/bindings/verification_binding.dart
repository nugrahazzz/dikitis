import 'package:dikitis/features/email_verification/data/data_source/verification_remote_data_source.dart';
import 'package:dikitis/features/email_verification/data/repositories/verification_repository_impl.dart';
import 'package:dikitis/features/email_verification/domain/repositories/verification_repository.dart';
import 'package:dikitis/features/email_verification/domain/usecases/check_verification_code.dart';
import 'package:dikitis/features/email_verification/domain/usecases/create_verification_code.dart';
import 'package:dikitis/features/email_verification/presentation/controllers/verification_controller.dart';
import 'package:get/get.dart';

class VerificationBinding implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      //Controller
      Bind.lazyPut(
        () => VerificationController(
          createVerificationCodeUseCase: Get.find(),
          checkVerificationCodeUseCase: Get.find(),
        ),
      ),
      //Datasource
      Bind.lazyPut<VerificationRemoteDataSource>(() => VerificationRemoteDataSourceImpl(apiService: Get.find())),
      //Repository
      Bind.lazyPut<VerificationRepository>(() => VerificationRepositoryImpl(
            remoteDataSource: Get.find(),
          )),
      //Usecase
      Bind.lazyPut(() => CheckVerificationCodeUseCase(Get.find())),
      Bind.lazyPut(() => CreateVerificationCodeUseCase(Get.find())),
    ];
  }
}
