import 'dart:math' as math;

import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/email_verification/presentation/controllers/verification_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class VerificationPage extends GetView<VerificationController> {
  const VerificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    bool isKeyboardShowing = MediaQuery.of(context).viewInsets.vertical > 0;

    return BackButtonListener(
      onBackButtonPressed: () {
        showCustomDialog(
            title: 'cancelVerification'.tr,
            description: 'cancelVerificationDesc'.tr,
            function: () {
              Get.offAllNamed(Routes.authenticationPage);
            },
            buttonText: 'leave'.tr,
            imagePath: LottiePath.exit,
            colorStatusBar: AppColors.bgDark,
            colorNavigationBar: AppColors.bgDark);

        return Future<bool>.value(true);
      },
      child: Scaffold(
        backgroundColor: AppColors.bgDark,
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(
                top: 8.0.wp,
                right: 8.0.wp,
                left: 8.0.wp,
              ),
              child: Center(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      SizedBox(
                        width: 60.0.wp,
                        child: Lottie.asset(
                          LottiePath.mail,
                          repeat: true,
                          animate: true,
                          fit: BoxFit.cover,
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          //
                          Text(
                            "emailVerification".tr,
                            style: AppTextStyles.poppinsBold.copyWith(
                              color: AppColors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 5.4.wp,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          //
                          SizedBox(
                            height: 2.0.wp,
                          ),
                          //
                          RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                                style: AppTextStyles.poppinsSemiBold
                                    .copyWith(color: AppColors.white, fontWeight: FontWeight.w100, fontSize: 3.3.wp, letterSpacing: 0.3, height: 1.3),
                                children: [
                                  TextSpan(
                                    text: 'verificationDesc1'.tr,
                                    // "An OTP verification code will be sent via your email ",
                                  ),
                                  TextSpan(
                                    text: " ",
                                    style: TextStyle(
                                      color: AppColors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextSpan(
                                    text: "(${Get.arguments['email'].toString()})",
                                    style: TextStyle(
                                      color: AppColors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextSpan(
                                    text: ". ",
                                    style: TextStyle(
                                      color: AppColors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextSpan(
                                    text: "verificationDesc2".tr,
                                    //. You need to enter code to active your account
                                  ),
                                ]),
                          ),
                          //
                          SizedBox(
                            height: 4.5.hp,
                          ),
                          //
                          // Padding(
                          //   padding: EdgeInsets.symmetric(horizontal: 2.0.wp),
                          //   child: MaterialPinField(
                          //     theme: MaterialPinTheme(),
                          //     autoFocus: false,
                          //     // appContext: context,
                          //     keyboardType: TextInputType.phone,
                          //     enableAutofill: false,
                          //     inputFormatters: [
                          //       FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          //     ],
                          //     length: 6,
                          //     obscureText: false,
                          //     blinkDuration: const Duration(milliseconds: 300),
                          //     hapticFeedbackType: HapticFeedbackType.medium,
                          //     // Pass it here
                          //     autoDisposeControllers: true,
                          //     autoDismissKeyboard: true,
                          //     cursorColor: AppColors.white,
                          //     textStyle: TextStyle(color: AppColors.white, fontWeight: FontWeight.w900),
                          //     pinTheme: PinTheme(
                          //       shape: PinCodeFieldShape.box,
                          //       borderRadius: BorderRadius.circular(8),
                          //       fieldHeight: 12.5.wp,
                          //       fieldWidth: 10.0.wp,
                          //       activeFillColor: AppColors.white,
                          //       activeColor: AppColors.cyan,
                          //       inactiveColor: AppColors.white,
                          //       selectedColor: AppColors.white,
                          //       selectedFillColor: AppColors.red,
                          //     ),
                          //     autoUnfocus: true,
                          //     enableActiveFill: false,
                          //     onCompleted: (value) {
                          //       controller.checkVerificationCodeC(inputCode: int.tryParse(value)!, email: Get.arguments['email'].toString());
                          //     },
                          //     onChanged: (value) {
                          //       controller.update();
                          //     },
                          //     beforeTextPaste: (text) {
                          //       return false;
                          //     },
                          //   ),
                          // ),
                        ],
                      ),
                      isKeyboardShowing
                          ? const SizedBox.shrink()
                          : Container(
                              margin: EdgeInsets.only(top: 35.0.wp),
                              color: AppColors.transparent,
                              child: Obx(() => (controller.isResendCodeVisible.value == true)
                                  ? GestureDetector(
                                      onTap: () {
                                        controller.resentVerificationCodeC(email: Get.arguments['email'].toString());
                                      },
                                      child: Container(
                                        color: AppColors.transparent,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "didNotReceive".tr,
                                              style: AppTextStyles.poppinsMedium.copyWith(
                                                color: AppColors.white,
                                                fontWeight: FontWeight.w600,
                                                letterSpacing: 0.3,
                                                wordSpacing: 0.3,
                                                fontSize: 3.6.wp,
                                              ),
                                            ),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Transform.rotate(
                                                  angle: math.pi * 0.63,
                                                  child: Transform.flip(
                                                    flipX: true,
                                                    child: Image.asset(
                                                      ImagePath.dashedArrow,
                                                      width: 5.0.wp,
                                                      color: AppColors.cyan.withValues(alpha: 0.75),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 4.0.wp,
                                                ),
                                                Text(
                                                  'resendCode'.tr,
                                                  style: AppTextStyles.poppinsSemiBold.copyWith(
                                                    color: AppColors.cyan,
                                                    fontWeight: FontWeight.bold,
                                                    letterSpacing: 0.2,
                                                    wordSpacing: 0.2,
                                                    fontSize: 4.0.wp,
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 4.0.wp,
                                                ),
                                                Transform.rotate(
                                                  angle: math.pi * 0.36,
                                                  child: Transform.flip(
                                                    flipY: true,
                                                    flipX: true,
                                                    child: Image.asset(
                                                      ImagePath.dashedArrow,
                                                      width: 5.0.wp,
                                                      color: AppColors.cyan.withValues(alpha: 0.75),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  : SizedBox(
                                      height: 13.5.wp,
                                    )),
                            ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
