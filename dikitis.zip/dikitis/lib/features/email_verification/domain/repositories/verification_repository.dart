import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/base_object_response.dart';
import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';

abstract class VerificationRepository {
  Future<Either<Failure, BaseObjectResponse>> checkVerificationCode(VerificationEntity verification);

  Future<Either<Failure, BaseObjectResponse>> createVerificationCode(VerificationEntity verification);
}
