import 'package:equatable/equatable.dart';

class VerificationEntity extends Equatable {
  final String? id;
  final String email;
  final String? codeVerification;

  const VerificationEntity({this.id, required this.email, this.codeVerification});

  @override
  List<Object?> get props => [id, email, codeVerification];
}
