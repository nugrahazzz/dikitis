import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/email_verification/domain/entities/verification_entity.dart';
import 'package:dikitis/features/email_verification/domain/repositories/verification_repository.dart';

class CreateVerificationCodeUseCase implements UseCase<void, Params<VerificationEntity>> {
  final VerificationRepository repository;

  CreateVerificationCodeUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(Params params) {
    return repository.createVerificationCode(params.data);
  }
}
