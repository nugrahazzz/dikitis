import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class CreditPage extends StatefulWidget {
  const CreditPage({super.key});

  @override
  State<CreditPage> createState() => _CreditPageState();
}

class _CreditPageState extends State<CreditPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 4.0.wp,
        ).copyWith(top: 3.0.wp),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              Center(
                  child: Image.asset(
                ImagePath.appLogo,
                width: 37.5.wp,
              )),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 250),
                child: Text(
                  "Dikitis App",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 6.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 1.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 500),
                child: Text(
                  "© Agung Nugraha",
                  style: AppTextStyles.poppinsSemiBold.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.0.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.5.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 750),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.0.wp),
                  child: Text(
                    "Dikitis App is available as Open Source Software under GPLv3 license. Dikitis Logo and Name is trademark of Dikitis App",
                    style: AppTextStyles.poppinsMedium.copyWith(
                      color: AppColors.white,
                      fontWeight: FontWeight.normal,
                      fontSize: 3.0.wp,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1000),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0.wp, vertical: 4.0.wp),
                  child: Divider(
                    height: 2,
                    thickness: 2,
                    color: AppColors.cyan,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1250),
                child: Text(
                  "Framework",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.cyan,
                    fontWeight: FontWeight.bold,
                    fontSize: 4.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1500),
                child: Text(
                  "Flutter",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 4.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1750),
                child: Text(
                  "Languages",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.cyan,
                    fontWeight: FontWeight.bold,
                    fontSize: 4.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "Dart",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "Java",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "SQL",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "HTML (Markup)",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "CSS",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2000),
                child: Text(
                  "PHP",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 4.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2250),
                child: Text(
                  "Art Credit",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.cyan,
                    fontWeight: FontWeight.bold,
                    fontSize: 4.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2500),
                child: Text(
                  "Undraw",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2500),
                child: Text(
                  "Lottie",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2500),
                child: Text(
                  "Icon8",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 4.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 2750),
                child: Text(
                  "Programs",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.cyan,
                    fontWeight: FontWeight.bold,
                    fontSize: 4.5.wp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.0.wp,
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 3000),
                child: Text(
                  "Android Studio",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 3000),
                child: Text(
                  "Visual Studio Code",
                  style: AppTextStyles.poppinsMedium.copyWith(
                    color: AppColors.white,
                    fontWeight: FontWeight.normal,
                    fontSize: 3.5.wp,
                  ),
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 3250),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0.wp, vertical: 4.0.wp),
                  child: Divider(
                    height: 2,
                    thickness: 2,
                    color: AppColors.cyan,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
