import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dikitis/features/change_language/data/data_source/change_language_local_data_source.dart';
import 'package:dikitis/features/change_language/domain/repositories/change_language_repository.dart';
import 'package:flutter/material.dart';

class ChangeLanguageRepositoryImpl implements ChangeLanguageRepository {
  final ChangeLanguageLocalDataSource localDataSource;

  ChangeLanguageRepositoryImpl({
    required this.localDataSource,
  });

  @override
  Future<Either<Failure, Locale>> getLocaleLanguage() async {
    try {
      final Locale result = await localDataSource.getLocaleLanguage();
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }

  @override
  Future<Either<Failure, void>> setLocaleLanguage(Locale locale) async {
    try {
      final result = await localDataSource.setLocaleLanguage(locale);
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }
}
