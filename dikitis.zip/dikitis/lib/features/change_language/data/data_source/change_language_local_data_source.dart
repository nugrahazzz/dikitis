import 'package:dikitis/core/services/database_service.dart';
import 'package:flutter/material.dart';

abstract class ChangeLanguageLocalDataSource {
  Future<Locale> getLocaleLanguage();

  Future<void> setLocaleLanguage(Locale locale);
}

class ChangeLanguageLocalDataSourceImpl implements ChangeLanguageLocalDataSource {
  final DatabaseService databaseService;

  ChangeLanguageLocalDataSourceImpl({required this.databaseService});

  final String _localeLanguageKey = "localeLanguage";

  @override
  Future<void> setLocaleLanguage(Locale locale) async {
    // Konversi Locale ke String
    final localeString = '${locale.languageCode}_${locale.countryCode ?? ''}';
    await databaseService.write(_localeLanguageKey, localeString);
  }

  @override
  Future<Locale> getLocaleLanguage() async {
    // Baca data sebagai String
    final localeString = await databaseService.read(_localeLanguageKey) ?? 'en_US'; // Default ke 'en_US'
    // Konversi kembali String ke Locale
    final parts = localeString.split('_');
    return Locale(parts[0], parts.length > 1 ? parts[1] : null);
  }
}
