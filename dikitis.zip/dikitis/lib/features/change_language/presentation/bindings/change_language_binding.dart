import 'package:dikitis/features/change_language/data/data_source/change_language_local_data_source.dart';
import 'package:dikitis/features/change_language/data/repositories/change_language_repository_impl.dart';
import 'package:dikitis/features/change_language/domain/repositories/change_language_repository.dart';
import 'package:dikitis/features/change_language/domain/usecases/get_locale_language.dart';
import 'package:dikitis/features/change_language/domain/usecases/set_local_language.dart';
import 'package:dikitis/features/change_language/presentation/controllers/change_language_controller.dart';
import 'package:get/get.dart';

class ChangeLanguageBinding implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      //Controller
      Bind.lazyPut<ChangeLanguageController>(() => ChangeLanguageController(
            setLocaleLanguageUseCase: Get.find(),
            getLocaleLanguageUseCase: Get.find(),
          )),
      //Datasource
      Bind.lazyPut<ChangeLanguageLocalDataSource>(() => ChangeLanguageLocalDataSourceImpl(databaseService: Get.find())),

      //Repository
      Bind.lazyPut<ChangeLanguageRepository>(() => ChangeLanguageRepositoryImpl(
            localDataSource: Get.find(),
          )),
      //Usecase
      Bind.lazyPut(() => SetLocaleLanguageUseCase(Get.find())),
      Bind.lazyPut(() => GetLocaleLanguageUseCase(Get.find())),
      Bind.lazyPut(() => GetLocaleLanguageUseCase(Get.find())),
    ];
  }
}
