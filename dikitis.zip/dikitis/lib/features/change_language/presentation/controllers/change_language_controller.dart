import 'package:dartz/dartz.dart';
import 'package:dikitis/config/translations/localization_translations.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/change_language/domain/usecases/get_locale_language.dart';
import 'package:dikitis/features/change_language/domain/usecases/set_local_language.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChangeLanguageController extends GetxController {
  final SetLocaleLanguageUseCase setLocaleLanguageUseCase;
  final GetLocaleLanguageUseCase getLocaleLanguageUseCase;

  ChangeLanguageController({
    required this.setLocaleLanguageUseCase,
    required this.getLocaleLanguageUseCase,
  });

  // Obx variables
  var selectedOption = 0.obs;

  final locales = LocalizationTranslations.locale;
  final languages = LocalizationTranslations.langs;
  final iconPaths = LocalizationTranslations.iconLangs;

  @override
  void onInit() async {
    // Call getLocaleLanguageSelectedIndex in onInit to set the selected language
    final int selectedIndex = await getCurrentLocaleIndex();
    selectedOption.value = selectedIndex;
    super.onInit();
  }

  /// Change language based on selected index
  void setLocaleLanguage(int index) async {
    selectedOption.value = index;
    final Locale selectedLocale = locales[index];

    // Save selected language to local storage
    await setLocaleLanguageUseCase(Params(selectedLocale)).then((_) {
      LocalizationTranslations.changeLocale(locale: selectedLocale);
    });
  }

  Future<int> getCurrentLocaleIndex() async {
    final Either<Failure, Locale> result = await getLocaleLanguageUseCase(NoParams());

    return result.fold((Failure failure) {
      showCustomSnackBar(title: failure.message, description: "(error code: ${failure.code})");
      return 0;
    }, (Locale locale) {
      // Temukan index dari locale yang disimpan dalam daftar
      final index = locales.indexWhere((data) => data.languageCode == locale.languageCode && data.countryCode == locale.countryCode);

      // Jika ditemukan, kembalikan index, jika tidak, kembalikan index default (misalnya 0)
      return index >= 0 ? index : 0;
    });
  }
}
