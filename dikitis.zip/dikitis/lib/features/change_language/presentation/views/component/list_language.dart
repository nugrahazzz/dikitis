import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class ListLanguage extends StatefulWidget {
  final String assetPath;
  final String title;
  final Color borderColor;
  final Function() function;

  const ListLanguage({
    super.key,
    required this.assetPath,
    required this.title,
    required this.borderColor,
    required this.function,
  });

  @override
  State<ListLanguage> createState() => _ListLanguageState();
}

class _ListLanguageState extends State<ListLanguage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        widget.function();
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 6.0.wp),
        decoration:
            BoxDecoration(border: Border.all(width: 0.5.wp, color: widget.borderColor), borderRadius: BorderRadius.all(Radius.circular(4.0.wp))),
        height: 20.0.wp,
        child: Row(
          children: [
            Flexible(
              flex: 4,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 5.0.wp, bottom: 5.0.wp, left: 4.0.wp, right: 5.0.wp),
                    decoration: BoxDecoration(color: AppColors.white.withValues(alpha: 0.2), shape: BoxShape.circle),
                    child: Padding(
                        padding: EdgeInsets.all(0.25.wp),
                        child: widget.assetPath == ""
                            ? Icon(
                                Icons.language_rounded,
                                color: AppColors.white,
                              )
                            : Image.asset(widget.assetPath)),
                  ),
                  Text(
                    widget.title,
                    style: AppTextStyles.poppinsSemiBold.copyWith(color: AppColors.white, fontSize: 4.5.wp),
                  ),
                ],
              ),
            ),
            Flexible(
                flex: 1,
                child: Container(
                  decoration: BoxDecoration(
                      color: (widget.borderColor != AppColors.white) ? widget.borderColor.withValues(alpha: 0.95) : AppColors.transparent,
                      shape: BoxShape.circle),
                  height: 4.0.wp,
                ))
          ],
        ),
      ),
    );
  }
}
