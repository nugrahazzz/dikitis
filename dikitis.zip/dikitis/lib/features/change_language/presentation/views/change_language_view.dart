import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/features/change_language/presentation/controllers/change_language_controller.dart';
import 'package:dikitis/features/change_language/presentation/views/component/list_language.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ChangeLanguagePage extends GetView<ChangeLanguageController> {
  const ChangeLanguagePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 5.0.wp),
        child: Center(
          child: Obx(
            () => SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    ImagePath.translate,
                    width: 50.0.wp,
                    color: AppColors.white,
                  ),
                  SizedBox(
                    height: 2.0.wp,
                  ),
                  IntrinsicHeight(
                    child: Padding(
                      padding: EdgeInsets.only(right: 6.0.wp),
                      child: SizedBox.expand(
                        child: Text(
                          'selectLang'.tr,
                          textAlign: TextAlign.start,
                          style: AppTextStyles.poppinsBold.copyWith(
                            fontSize: 5.2.wp,
                            letterSpacing: 1.8,
                            color: AppColors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 8.0.wp, top: 6.0.wp),
                    child: DottedBorder(
                      options: RectDottedBorderOptions(
                        color: AppColors.white,
                        dashPattern: const [12, 18],
                        strokeWidth: controller.selectedOption.value == controller.selectedOption.value ? 2 : 2,
                      ),
                      child: Container(
                        height: 0.1,
                      ),
                    ),
                  ),
                  // List Language
                  ListView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    itemCount: controller.languages.length,
                    itemBuilder: (BuildContext context, int index) {
                      return ListLanguage(
                        assetPath: controller.iconPaths[index],
                        title: controller.languages[index],
                        borderColor: controller.selectedOption.value == index ? AppColors.cyan : AppColors.white,
                        function: () {
                          controller.setLocaleLanguage(index);
                        },
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
