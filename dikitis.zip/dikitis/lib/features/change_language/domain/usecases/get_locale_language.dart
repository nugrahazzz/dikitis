import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/change_language/domain/repositories/change_language_repository.dart';
import 'package:flutter/material.dart';

class GetLocaleLanguageUseCase implements UseCase<Locale, NoParams> {
  final ChangeLanguageRepository repository;

  GetLocaleLanguageUseCase(this.repository);

  @override
  Future<Either<Failure, Locale>> call(NoParams params) {
    return repository.getLocaleLanguage();
  }
}
