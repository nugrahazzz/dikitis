import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/change_language/domain/repositories/change_language_repository.dart';
import 'package:flutter/material.dart';

class SetLocaleLanguageUseCase implements UseCase<void, Params<Locale>> {
  final ChangeLanguageRepository repository;

  SetLocaleLanguageUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(Params params) {
    return repository.setLocaleLanguage(params.data);
  }
}
