import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:flutter/material.dart';

abstract class ChangeLanguageRepository {
  Future<Either<Failure, Locale>> getLocaleLanguage();

  Future<Either<Failure, void>> setLocaleLanguage(Locale locale);
}
