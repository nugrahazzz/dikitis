import 'package:dikitis/features/authentication/data/data_source/authentication_local_data_source.dart';
import 'package:dikitis/features/authentication/data/data_source/authentication_remote_data_source.dart';
import 'package:dikitis/features/authentication/data/repositories/authentication_repository_impl.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';
import 'package:dikitis/features/authentication/domain/usecases/set_is_logged_in.dart';
import 'package:dikitis/features/authentication/domain/usecases/sign_in.dart';
import 'package:dikitis/features/authentication/domain/usecases/sign_up.dart';
import 'package:dikitis/features/authentication/presentation/controllers/authentication_controller.dart';
import 'package:get/get.dart';

class AuthenticationBinding implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      //Controller
      Bind.lazyPut<AuthenticationController>(() => AuthenticationController(
            signInUseCase: Get.find(),
            signUpUseCase: Get.find(),
            setIsLoggedInUseCase: Get.find(),
          )),
      //Datasource
      Bind.lazyPut<AuthenticationLocalDataSource>(() => AuthenticationLocalDataSourceImpl(databaseService: Get.find())),
      Bind.lazyPut<AuthenticationRemoteDataSource>(() => AuthenticationRemoteDataSourceImpl(apiService: Get.find())),

      //Repository
      Bind.lazyPut<AuthenticationRepository>(() => AuthenticationRepositoryImpl(
            remoteDataSource: Get.find(),
            localDataSource: Get.find(),
          )),
      //Usecase
      Bind.lazyPut(() => SignInUseCase(Get.find())),
      Bind.lazyPut(() => SignUpUseCase(Get.find())),
      Bind.lazyPut(() => SetIsLoggedInUseCase(Get.find())),
    ];
  }
}
