import 'dart:math' as math;

import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/authentication/presentation/controllers/authentication_controller.dart';
import 'package:dikitis/features/authentication/presentation/widgets/animated_lotties.dart';
import 'package:dikitis/features/authentication/presentation/widgets/background_images.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';

class AuthenticationPage extends GetView<AuthenticationController> {
  const AuthenticationPage({super.key});

  @override
  Widget build(BuildContext context) {
    bool isKeyboardShowing = MediaQuery.of(context).viewInsets.vertical > 0;

    return BackButtonListener(
      onBackButtonPressed: () {
        controller.unFocusTextField();

        showCustomDialog(
          colorStatusBar: AppColors.transparent,
          colorNavigationBar: AppColors.bgDark,
        );

        return Future<bool>.value(true);
      },
      child: Scaffold(
        backgroundColor: AppColors.bgDark,
        drawerScrimColor: AppColors.bgDark,
        body: Stack(
          children: [
            const BackgroundImages(),
            Obx(
              () => Padding(
                padding: EdgeInsets.symmetric(horizontal: 6.0.wp),
                child: Center(
                  child: SingleChildScrollView(
                    physics: const NeverScrollableScrollPhysics(),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(height: 9.0.hp),
                        AnimatedLottie(
                          isLoginScreen: controller.isLoginScreen.value,
                          isKeyboardShowing: isKeyboardShowing,
                        ),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 400),
                          height: isKeyboardShowing ? 1.0.hp : 2.5.hp,
                        ),
                        Column(
                          children: <Widget>[
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              height: controller.isLoginScreen.value ? 0 : 20.0.wp,
                              child: controller.isLoginScreen.value
                                  ? SizedBox.shrink()
                                  : CustomTextField(
                                      controller: controller.fullnameController,
                                      hintText: "fullname".tr,
                                      colorHint: AppColors.bgDark.withValues(alpha: 0.7),
                                      colorIcon: AppColors.cyan,
                                      currentNode: controller.fullnameFocus,
                                      nextNode: controller.emailFocus,
                                      useSuffixIcon: false,
                                      textCapitalization: TextCapitalization.words,
                                      filteringTextInputFormatter: [
                                        FilteringTextInputFormatter.allow(RegExp('[a-z A-Z (space)]')),
                                      ],
                                    ),
                            ),
                            CustomTextField(
                              controller: controller.emailController,
                              icon: Icons.email_outlined,
                              hintText: "email".tr,
                              colorHint: AppColors.bgDark.withValues(alpha: 0.7),
                              colorIcon: AppColors.cyan,
                              currentNode: controller.emailFocus,
                              nextNode: controller.passwordFocus,
                              useSuffixIcon: false,
                              filteringTextInputFormatter: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                            ),
                            CustomTextField(
                              controller: controller.passwordController,
                              hintText: "password".tr,
                              colorHint: AppColors.bgDark.withValues(alpha: 0.7),
                              visibility: controller.isPasswordVisible.value,
                              currentNode: controller.passwordFocus,
                              icon: Icons.lock_rounded,
                              colorIcon: AppColors.cyan,
                              useSuffixIcon: true,
                              iconSuffix: controller.isPasswordVisible.value ? Icons.remove_red_eye : Icons.remove_red_eye_outlined,
                              function: controller.togglePasswordVisibility,
                              filteringTextInputFormatter: [FilteringTextInputFormatter.deny(RegExp(r"\s\b|\b\s"))],
                              nextNode: null,
                            ),
                          ],
                        ),
                        SizedBox(height: 1.5.hp),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          height: isKeyboardShowing ? 0 : 36.0.wp,
                          child: Container(
                            color: AppColors.transparent,
                            child: SingleChildScrollView(
                              physics: const NeverScrollableScrollPhysics(), // Fix scroll
                              child: Column(
                                children: [
                                  Obx(
                                    () => controller.isLoading.value
                                        ? SizedBox(
                                            height: 14.0.wp,
                                            child: Center(
                                              child: SpinKitWave(
                                                color: AppColors.white,
                                                size: 6.0.wp,
                                              ),
                                            ),
                                          )
                                        : CustomButton(
                                            onlyIcon: false,
                                            borderRadius: 12,
                                            height: 14.0.wp,
                                            color: AppColors.cyan,
                                            borderColor: AppColors.cyan,
                                            titleColor: AppColors.bgDark,
                                            title: controller.isLoginScreen.value ? "login".tr : "registration".tr,
                                            function: () async {
                                              if (!Get.isSnackbarOpen) {
                                                controller.unFocusTextField();
                                                if (controller.isLoginScreen.value) {
                                                  checkConnectionBeforeExecute(function: controller.signIn);
                                                } else {
                                                  checkConnectionBeforeExecute(function: controller.register);
                                                }
                                              }
                                            },
                                          ),
                                  ),
                                  SizedBox(height: 8.0.wp),
                                  GestureDetector(
                                    onTap: controller.switchScreen,
                                    child: Container(
                                      color: AppColors.transparent,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            controller.isLoginScreen.value ? "dontHaveAnAccount".tr : "alreadyHaveAnAccount".tr,
                                            style: AppTextStyles.poppinsMedium.copyWith(
                                              color: AppColors.white,
                                              fontWeight: FontWeight.w600,
                                              letterSpacing: 0.3,
                                              wordSpacing: 0.3,
                                              fontSize: 3.6.wp,
                                            ),
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Transform.rotate(
                                                angle: math.pi * 0.63,
                                                child: Transform.flip(
                                                  flipX: true,
                                                  child: Image.asset(
                                                    ImagePath.dashedArrow,
                                                    width: 5.0.wp,
                                                    color: AppColors.cyan.withValues(alpha: 0.75),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 4.0.wp,
                                              ),
                                              Text(
                                                controller.isLoginScreen.value ? "letsRegistration".tr : "letsLogin".tr,
                                                style: AppTextStyles.poppinsSemiBold.copyWith(
                                                  color: AppColors.cyan,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 0.2,
                                                  wordSpacing: 0.2,
                                                  fontSize: 4.0.wp,
                                                  // decorationThickness: 1.0,
                                                  // decoration: TextDecoration.underline,
                                                  // decorationStyle: TextDecorationStyle.dotted,
                                                  // decorationColor: AppColors.cyan,
                                                ),
                                              ),
                                              SizedBox(
                                                width: 4.0.wp,
                                              ),
                                              Transform.rotate(
                                                angle: math.pi * 0.36,
                                                child: Transform.flip(
                                                  flipY: true,
                                                  flipX: true,
                                                  child: Image.asset(
                                                    ImagePath.dashedArrow,
                                                    width: 5.0.wp,
                                                    color: AppColors.cyan.withValues(alpha: 0.75),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Future<void> setUserInformation({required String id}) async {
//   try {
//     var checkId = LocalStorageServices().getId();
//
//     if (checkId.isEmpty || checkId == "") {
//       UserServices userService = UserServices();
//       var result = await userService.readUserData(idUser: id);
//       LocalStorageServices().saveUserData(patient: result.data!);
//       update();
//     }
//   } catch (error) {
//     if (kDebugMode) {
//       print(error);
//     }
//   } finally {
//     isLoading(false);
//   }
// }

// Future<void> signInC() async {
//   if (emailTextEditingController.text.isEmpty) {
//     showCustomSnackBar(title: "emailNull".tr, description: "fieldNull".tr);
//   } else if (passwordTextEditingController.text.isEmpty) {
//     showCustomSnackBar(title: "passwordNull".tr, description: "fieldNull".tr);
//   } else {
//     if (!GetUtils.isEmail(emailTextEditingController.text)) {
//       showCustomSnackBar(title: "emailInvalid".tr, description: "emailInvalidDesc".tr);
//     } else {
//       isLoading(true);
//
//       Authentication user = Authentication(email: emailTextEditingController.text, password: passwordTextEditingController.text);
//       final Either<Failure, AuthenticationResponse> results = await signInUseCase(Params(user));
//
//       return results.fold(
//         (Failure failure) {
//           showCustomSnackBar(title: failure.message, description: "(Error code: ${failure.code})");
//           isLoading(false);
//         },
//         (AuthenticationResponse userResponse) async {
//           //check role
//           if (userResponse.data.role == "patient") {
//             //check akun sudah aktif
//             if (userResponse.data.isActive == 1) {
//               // save user ke local storage
//               final Either<Failure, void> results = await setIsLoggedInUseCase(Params(true));
//               return results.fold((Failure failure) {
//                 showCustomSnackBar(title: failure.message, description: "(Error code: ${failure.code})");
//                 throw "${failure.message} \n (error code: ${failure.code})";
//               }, (_) {
//                 clearTextField();
//                 Get.offNamed(Routes.homePage, arguments: userResponse.data.id);
//               });
//             } else {
//               //belum verifikasi
//               showCustomDialog(
//                   title: 'verificationAccount'.tr,
//                   description: 'verificationAccountDesc'.tr,
//                   function: () {
//                     Get.back();
//                     //
//                     Get.toNamed(
//                       Routes.userVerificationPage,
//                       arguments: {
//                         'email': emailTextEditingController.text,
//                         'password': passwordTextEditingController.text,
//                         'fullname': fullnameTextEditingController.text,
//                       }, // Pass multiple arguments
//                     );
//                   },
//                   buttonText: 'continueVerification'.tr,
//                   imagePath: LottiePath.settings,
//                   colorStatusBar: AppColors.transparent,
//                   colorNavigationBar: AppColors.bgDark);
//             }
//           } else {
//             showCustomSnackBar(title: "roleInvalid".tr, description: "roleInvalidDesc".tr);
//           }
//           isLoading(false);
//         },
//       );
//     }
//   }
// }

// Future<void> registrationC() async {
//   if (fullnameTextEditingController.text.isEmpty) {
//     showCustomSnackBar(title: "fullnameNull".tr, description: "fieldNull".tr);
//   } else if (emailTextEditingController.text.isEmpty) {
//     showCustomSnackBar(title: "emailNull".tr, description: "fieldNull".tr);
//   } else if (passwordTextEditingController.text.isEmpty) {
//     showCustomSnackBar(title: "passwordNull".tr, description: "fieldNull".tr);
//   } else if (passwordTextEditingController.text.length < 8) {
//     showCustomSnackBar(title: "Password minimal 8 karakter", description: "Silahkan perbaiki password Anda");
//   } else {
//     if (!GetUtils.isEmail(emailTextEditingController.text)) {
//       showCustomSnackBar(title: "emailInvalid".tr, description: "emailInvalidDesc".tr);
//     } else {
//       isLoading(true);
//
//       Authentication user = Authentication(
//         id: "P-${DateTime.now().millisecondsSinceEpoch}",
//         email: emailTextEditingController.text.toLowerCase(),
//         password: passwordTextEditingController.text,
//         role: "patient",
//         isActive: 0,
//         //
//         // fullname: fullnameTextEditingController.text,
//         // photoUrl: "",
//         // address: "",
//       );
//
//       final Either<Failure, AuthenticationResponse> results = await signInUseCase(Params(user));
//
//       return results.fold(
//         (Failure failure) {
//           showCustomSnackBar(title: failure.message, description: "(Error code: ${failure.code})");
//         },
//         (_) async {
//           Get.toNamed(
//             Routes.userVerificationPage,
//             arguments: {
//               'email': emailTextEditingController.text,
//               'password': passwordTextEditingController.text,
//               'fullname': fullnameTextEditingController.text,
//             }, // Pass multiple arguments
//           );
//           clearTextField();
//         },
//       );
//     }
//   }
//   update();
// }
