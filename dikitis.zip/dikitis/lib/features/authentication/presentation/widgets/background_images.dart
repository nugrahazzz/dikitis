import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class BackgroundImages extends StatelessWidget {
  const BackgroundImages({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: -2.5.hp,
          left: -7.0.wp,
          child: Image.asset(
            ImagePath.flowTop,
            color: AppColors.cyan.withValues(alpha: 0.2),
            width: 35.0.wp,
          ),
        ),
        Positioned(
          bottom: -2.0.hp,
          right: -7.0.wp,
          child: Image.asset(
            ImagePath.flowBottom,
            width: 40.0.wp,
            color: AppColors.cyan.withValues(alpha: 0.2),
          ),
        ),
      ],
    );
  }
}
