import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class AnimatedLottie extends StatelessWidget {
  final bool isLoginScreen;
  final bool isKeyboardShowing;

  const AnimatedLottie({
    super.key,
    required this.isLoginScreen,
    required this.isKeyboardShowing,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      height: isLoginScreen
          ? 65.0.wp
          : !isKeyboardShowing
              ? 55.0.wp
              : 45.0.wp,
      child: Lottie.asset(
        LottiePath.doctor,
        reverse: false,
        fit: BoxFit.cover,
      ),
    );
  }
}
