import 'package:dartz/dartz.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/enums/user_role.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_in_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';
import 'package:dikitis/features/authentication/domain/usecases/set_is_logged_in.dart';
import 'package:dikitis/features/authentication/domain/usecases/sign_in.dart';
import 'package:dikitis/features/authentication/domain/usecases/sign_up.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AuthenticationController extends GetxController {
  final SignInUseCase signInUseCase;
  final SignUpUseCase signUpUseCase;
  final SetIsLoggedInUseCase setIsLoggedInUseCase;

  AuthenticationController({
    required this.signInUseCase,
    required this.signUpUseCase,
    required this.setIsLoggedInUseCase,
  });

  late TextEditingController fullnameController;
  late TextEditingController emailController;
  late TextEditingController passwordController;

  late FocusNode fullnameFocus;
  late FocusNode emailFocus;
  late FocusNode passwordFocus;

  RxBool isLoading = false.obs;
  RxBool isPasswordVisible = true.obs;
  RxBool isLoginScreen = true.obs;

  @override
  void onInit() {
    fullnameController = TextEditingController();
    emailController = TextEditingController();
    passwordController = TextEditingController();
    fullnameFocus = FocusNode();
    emailFocus = FocusNode();
    passwordFocus = FocusNode();
    super.onInit();
  }

  @override
  void onReady() {
    changeBarColor(
      statusBarColor: AppColors.transparent,
      navBarColor: AppColors.bgDark,
    );
    super.onReady();
  }

  @override
  void onClose() {
    fullnameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    fullnameFocus.dispose();
    emailFocus.dispose();
    passwordFocus.dispose();
    super.onClose();
  }

  Future<void> signIn() async {
    isLoading(true);
    if (!_validateEmailAndPassword()) {
      isLoading(false);
      return;
    }

    SignInRequestEntity signInData = SignInRequestEntity(
      email: emailController.text,
      password: passwordController.text,
    );

    Either<Failure, UserEntity> result = await signInUseCase(
      Params(signInData),
    );

    result.fold(
      (failure) => showErrorSnackbar(failure),
      (var auth) => _verifySignInProcess(auth),
    );

    isLoading(false);
  }

  Future<void> register() async {
    isLoading(true);

    if (!_validateRegistrationInputs()) return;

    SignUpRequestEntity registrationData = SignUpRequestEntity(
      id: "P-${DateTime.now().millisecondsSinceEpoch}",
      email: emailController.text.toLowerCase(),
      password: passwordController.text,
      fullname: fullnameController.text,
      role: UserRole.patient.name,
    );

    Either<Failure, UserEntity> result = await signUpUseCase(
      Params(registrationData),
    );

    result.fold(
      (failure) => showErrorSnackbar(failure),
      (authentication) => _navigateToVerificationPage(),
    );
    isLoading(false);
  }

  bool _validateEmailAndPassword() {
    if (emailController.text.isEmpty) {
      showCustomSnackBar(title: "emailNull".tr, description: "fieldNull".tr);
      return false;
    }
    if (passwordController.text.isEmpty) {
      showCustomSnackBar(title: "passwordNull".tr, description: "fieldNull".tr);
      return false;
    }
    if (!GetUtils.isEmail(emailController.text)) {
      showCustomSnackBar(title: "emailInvalid".tr, description: "emailInvalidDesc".tr);
      return false;
    }
    return true;
  }

  bool _validateRegistrationInputs() {
    if (fullnameController.text.isEmpty) {
      showCustomSnackBar(title: "fullnameNull".tr, description: "fieldNull".tr);
      return false;
    }
    if (!_validateEmailAndPassword()) return false;
    if (passwordController.text.length < 8) {
      showCustomSnackBar(
        title: "minLengthPassword".tr,
        description: "passwordError".tr,
      );
      return false;
    }
    return true;
  }

  void _verifySignInProcess(UserEntity userResponse) {
    if (userResponse.role.toString() == UserRole.patient.name) {
      if (userResponse.isActive == 1) {
        _completeSignInProcess(userResponse);
      } else {
        showCustomDialog(
          title: 'verificationAccount'.tr,
          description: 'verificationAccountDesc'.tr,
          function: () => _navigateToVerificationPage(),
          buttonText: 'continueVerification'.tr,
          imagePath: LottiePath.settings,
          colorStatusBar: AppColors.transparent,
          colorNavigationBar: AppColors.bgDark,
        );
      }
    } else {
      showCustomSnackBar(title: "roleInvalid".tr, description: "roleInvalidDesc".tr);
    }
  }

  Future<void> _completeSignInProcess(UserEntity userResponse) async {
    final loginResult = await setIsLoggedInUseCase(Params(true));

    loginResult.fold(
      (failure) => showErrorSnackbar(failure),
      (_) {
        clearTextField();
        Get.offNamed(Routes.homePage, arguments: userResponse.id);
      },
    );
  }

  void _navigateToVerificationPage() {
    Get.toNamed(
      Routes.emailVerificationPage,
      arguments: {
        'email': emailController.text,
        'password': passwordController.text,
        'fullname': fullnameController.text,
      },
    );
    clearTextField();
  }

  void switchScreen() {
    isLoginScreen.value = !isLoginScreen.value;
    unFocusTextField();
  }

  void unFocusTextField() {
    emailFocus.unfocus();
    fullnameFocus.unfocus();
    passwordFocus.unfocus();
  }

  void clearTextField() {
    emailController.clear();
    fullnameController.clear();
    passwordController.clear();
  }

  void togglePasswordVisibility() => isPasswordVisible.value = !isPasswordVisible.value;
}
