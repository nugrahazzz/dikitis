import 'package:dikitis/core/constant/api/api_path.dart';
import 'package:dikitis/core/services/rest_api_service.dart';
import 'package:dikitis/core/utils/helper/base_object_response.dart';
import 'package:dikitis/features/authentication/data/models/sign_in_request_model.dart';
import 'package:dikitis/features/authentication/data/models/sign_up_request_model.dart';
import 'package:dikitis/features/authentication/data/models/user_model.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_in_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';
import 'package:dio/dio.dart';

abstract class AuthenticationRemoteDataSource {
  Future<UserEntity> signIn(SignInRequestEntity user);

  Future<UserEntity> signUp(SignUpRequestEntity user);
}

class AuthenticationRemoteDataSourceImpl implements AuthenticationRemoteDataSource {
  final RestApiService apiService;

  AuthenticationRemoteDataSourceImpl({required this.apiService});

  @override
  Future<UserEntity> signIn(SignInRequestEntity user) async {
    final dataUser = SignInRequestModel(
      email: user.email,
      password: user.password,
    ).toJson();

    // API call
    final response = await apiService.post(
      endPoint: ApiPath.login,
      data: dataUser,
    );

    return _processResponse(response);
  }

  @override
  Future<UserEntity> signUp(SignUpRequestEntity user) async {
    final dataUser = SignUpRequestModel(
      id: user.id,
      email: user.email,
      password: user.password,
      role: user.role,
      fullname: user.fullname,
    ).toJson();

    // API call
    final response = await apiService.post(
      endPoint: ApiPath.registration,
      data: dataUser,
    );
    return _processResponse(response);
  }

  Future<UserEntity> _processResponse(Response<dynamic> response) async {
    final BaseObjectResponse<UserModel> parsedResponse = BaseObjectResponse.fromJson(response.data, (json) => UserModel.fromJson(json));

    if (parsedResponse.isSuccess == true) {
      return parsedResponse.data!;
    } else {
      throw parsedResponse.message;
    }
  }
}
