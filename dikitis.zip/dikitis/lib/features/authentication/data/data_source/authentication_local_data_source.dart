import 'package:dikitis/core/services/database_service.dart';

abstract class AuthenticationLocalDataSource {
  Future<bool> getIsLoggedIn();

  Future<void> setIsLoggedIn(bool status);

  Future<void> setUserData(String userJson);
}

class AuthenticationLocalDataSourceImpl implements AuthenticationLocalDataSource {
  final DatabaseService databaseService;

  AuthenticationLocalDataSourceImpl({required this.databaseService});

  final String _isLoggedKey = "isLoggedKey";
  final String _userKey = "userKey";

  @override
  Future<void> setIsLoggedIn(bool status) async {
    databaseService.write(_isLoggedKey, status);
  }

  @override
  Future<bool> getIsLoggedIn() async {
    bool isLoggedIn = await databaseService.read(_isLoggedKey) ?? false;
    return isLoggedIn;
  }

  @override
  Future<void> setUserData(String userJson) async {
    await databaseService.write(_userKey, userJson);
  }
}
