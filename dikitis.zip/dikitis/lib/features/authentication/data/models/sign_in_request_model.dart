import 'package:dikitis/features/authentication/domain/entities/sign_in_request_entity.dart';

class SignInRequestModel extends SignInRequestEntity {
  const SignInRequestModel({
    required super.email,
    required super.password,
  });

  Map<String, dynamic> toJson() {
    return {
      "user_email": email,
      "user_password": password,
    };
  }
}
