import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  const UserModel({
    super.id,
    super.email,
    super.role,
    super.isActive,
    super.fullname,
    super.photoUrl,
    super.address,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json["user_id"] as String?,
      email: json["user_email"] ?? "",
      role: json["user_role"] ?? "patient",
      isActive: json["user_is_active"] != null ? int.tryParse(json["user_is_active"].toString()) : 0,
      fullname: json["patient_fullname"],
      photoUrl: json["patient_photo_url"],
      address: json["patient_address"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "user_id": id,
      "user_email": email,
      "user_role": role,
      "user_is_active": isActive,
      "patient_fullname": fullname,
      "patient_photo_url": photoUrl,
      "patient_address": address,
    };
  }

  UserEntity toEntity() {
    return UserEntity(
      id: id,
      email: email,
      role: role,
      isActive: isActive,
      fullname: fullname,
      photoUrl: photoUrl,
      address: address,
    );
  }
}
