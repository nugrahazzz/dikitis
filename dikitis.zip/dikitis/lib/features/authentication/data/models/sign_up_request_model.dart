import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';

class SignUpRequestModel extends SignUpRequestEntity {
  const SignUpRequestModel({super.id, required super.email, required super.password, required super.role, required super.fullname});

  Map<String, dynamic> toJson() {
    return {
      'user_id': id,
      'user_email': email,
      'user_password': password,
      'user_role': role,
      'patient_fullname': fullname,
    };
  }
}
