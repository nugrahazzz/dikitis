import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dikitis/features/authentication/data/data_source/authentication_local_data_source.dart';
import 'package:dikitis/features/authentication/data/data_source/authentication_remote_data_source.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_in_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';

class AuthenticationRepositoryImpl implements AuthenticationRepository {
  final AuthenticationRemoteDataSource remoteDataSource;
  final AuthenticationLocalDataSource localDataSource;

  AuthenticationRepositoryImpl({
    required this.remoteDataSource,
    required this.localDataSource,
  });

  @override
  Future<Either<Failure, UserEntity>> signIn(SignInRequestEntity user) async {
    try {
      final result = await remoteDataSource.signIn(user);

      return Right(result);
    } catch (e) {
      return Left(ErrorHandler.handle(e).failure);
    }
  }

  @override
  Future<Either<Failure, UserEntity>> signUp(SignUpRequestEntity user) async {
    try {
      final result = await remoteDataSource.signUp(user);
      return Right(result);
    } catch (e) {
      return Left(ErrorHandler.handle(e).failure);
    }
  }

  @override
  Future<Either<Failure, bool>> getIsLoggedIn() async {
    try {
      final result = await localDataSource.getIsLoggedIn();
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }

  @override
  Future<Either<Failure, void>> setIsLoggedIn(bool status) async {
    try {
      final result = await localDataSource.setIsLoggedIn(status);
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }
}
