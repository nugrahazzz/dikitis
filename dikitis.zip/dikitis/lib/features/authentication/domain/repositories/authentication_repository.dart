import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_in_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';

abstract class AuthenticationRepository {
  Future<Either<Failure, UserEntity>> signIn(SignInRequestEntity user);

  Future<Either<Failure, UserEntity>> signUp(SignUpRequestEntity user);

  Future<Either<Failure, bool>> getIsLoggedIn();

  Future<Either<Failure, void>> setIsLoggedIn(bool status);

// Future<Either<Failure, Patient>> getUserDetail();
}
