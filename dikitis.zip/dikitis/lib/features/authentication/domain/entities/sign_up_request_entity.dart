import 'package:equatable/equatable.dart';

class SignUpRequestEntity extends Equatable {
  final String? id;
  final String email;
  final String password;
  final String fullname;
  final String role;

  const SignUpRequestEntity({
    required this.id,
    required this.email,
    required this.password,
    required this.fullname,
    required this.role,
  });

  @override
  List<Object?> get props => [id, email, password, fullname, role];
}
