import 'package:equatable/equatable.dart';

class UserEntity extends Equatable {
  final String? id;
  final String? email;
  final String? role;
  final int? isActive;
  final String? fullname;
  final String? photoUrl;
  final String? address;

  const UserEntity({
    this.id,
    this.email,
    this.role,
    this.isActive,
    this.fullname,
    this.photoUrl,
    this.address,
  });

  @override
  List<Object?> get props => [
        id,
        email,
        role,
        isActive,
        fullname,
        photoUrl,
        address,
      ];
}
