import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';

class SetIsLoggedInUseCase implements UseCase<void, Params<bool>> {
  final AuthenticationRepository repository;

  SetIsLoggedInUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(Params params) {
    return repository.setIsLoggedIn(params.data);
  }
}
