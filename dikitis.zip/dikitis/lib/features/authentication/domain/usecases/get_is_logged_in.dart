import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';

class GetIsLoggedInUseCase implements UseCase<bool, NoParams> {
  final AuthenticationRepository repository;

  GetIsLoggedInUseCase(this.repository);

  @override
  Future<Either<Failure, bool>> call(NoParams params) {
    return repository.getIsLoggedIn();
  }
}
