import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/authentication/domain/entities/sign_up_request_entity.dart';
import 'package:dikitis/features/authentication/domain/entities/user_entity.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';

class SignUpUseCase implements UseCase<UserEntity, Params<SignUpRequestEntity>> {
  final AuthenticationRepository repository;

  SignUpUseCase(this.repository);

  @override
  Future<Either<Failure, UserEntity>> call(Params params) {
    return repository.signUp(params.data);
  }
}
