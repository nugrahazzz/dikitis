import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class CustomSeparator extends StatelessWidget {
  final Color color;

  const CustomSeparator({super.key, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      padding: EdgeInsets.symmetric(vertical: 1.1.wp),
      child: Divider(
        thickness: 1,
        color: color,
      ),
    );
  }
}
