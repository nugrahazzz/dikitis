import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class InformationCard extends StatelessWidget {
  final String title;
  final String description;

  const InformationCard({
    super.key,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.white,
      elevation: 0,
      margin: EdgeInsets.symmetric(vertical: 2.5.wp),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        padding: EdgeInsets.all(2.5.wp),
        child: Theme(
          data: Theme.of(context).copyWith(
            dividerColor: Colors.transparent,
            splashColor: Colors.transparent,
            colorScheme: ColorScheme.fromSwatch().copyWith(
              secondary: Colors.white,
            ),
          ),
          child: ExpansionTile(
            collapsedIconColor: AppColors.bgDark,
            iconColor: AppColors.cyan,
            childrenPadding: EdgeInsets.only(bottom: 2.0.wp),
            backgroundColor: Colors.white,
            collapsedBackgroundColor: Colors.white,
            title: Text(
              title,
              style: AppTextStyles.poppinsSemiBold.copyWith(
                fontWeight: FontWeight.w900,
                fontSize: 3.5.wp,
                letterSpacing: 0.8,
                color: AppColors.bgDark.withValues(alpha: 0.75),
              ),
            ),
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(
                  bottom: 2.5.wp,
                  right: 4.0.wp,
                  left: 4.0.wp,
                ),
                child: Divider(
                  height: 1,
                  thickness: 1,
                  color: AppColors.bgDark,
                ),
              ),
              ListTile(
                title: Text(
                  description,
                  style: AppTextStyles.poppinsSemiBold.copyWith(
                    color: AppColors.bgDark.withValues(alpha: 0.75),
                    fontSize: 3.2.wp,
                    letterSpacing: 0.3,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.justify,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
