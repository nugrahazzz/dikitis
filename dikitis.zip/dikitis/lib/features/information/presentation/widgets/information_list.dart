import 'package:dikitis/features/information/domain/entities/information_entity.dart';
import 'package:dikitis/features/information/presentation/widgets/information_card.dart';
import 'package:flutter/material.dart';

class InformationList extends StatelessWidget {
  final List<InformationEntity> informationList;

  const InformationList({super.key, required this.informationList});

  @override
  Widget build(BuildContext context) {
    return MediaQuery.removePadding(
      context: context,
      removeTop: true,
      child: RawScrollbar(
        thumbColor: Colors.transparent,
        thumbVisibility: true,
        thickness: 4,
        child: ListView.builder(
          itemCount: informationList.length,
          physics: const AlwaysScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            final info = informationList[index];
            return InformationCard(
              title: info.title,
              description: info.description,
            );
          },
        ),
      ),
    );
  }
}
