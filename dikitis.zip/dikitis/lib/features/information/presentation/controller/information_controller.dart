import 'package:dartz/dartz.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/information/domain/entities/information_entity.dart';
import 'package:dikitis/features/information/domain/usecases/read_information.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InformationController extends GetxController with StateMixin<List<InformationEntity>> {
  final ReadInformationUseCase readInformationUseCase;

  InformationController({
    required this.readInformationUseCase,
  });

  @override
  void onInit() {
    super.onInit();
    Future.delayed(const Duration(milliseconds: 750), () {
      futurize(() => readInformation());
    });
  }

  @override
  onReady() {
    super.onReady();
    changeBarColor(statusBarColor: Colors.transparent, navBarColor: AppColors.cyan[700]!);
  }

  Future<List<InformationEntity>> readInformation() async {
    final Either<Failure, List<InformationEntity>> results = await readInformationUseCase(NoParams());

    return results.fold((Failure failure) {
      //failed
      throw "${failure.message} \n (error code: ${failure.code})";
    }, (List<InformationEntity> data) {
      //success
      return data;
    });
  }
}
