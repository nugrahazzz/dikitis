import 'package:dikitis/features/information/data/data_source/information_remote_data_source.dart';
import 'package:dikitis/features/information/data/repositories/information_repository_impl.dart';
import 'package:dikitis/features/information/domain/repositories/information_repository.dart';
import 'package:dikitis/features/information/domain/usecases/read_information.dart';
import 'package:dikitis/features/information/presentation/controller/information_controller.dart';
import 'package:get/get.dart';

class InformationBinding implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      //Controller
      Bind.lazyPut(() => InformationController(readInformationUseCase: Get.find())),
      //Datasource
      Bind.lazyPut<InformationRemoteDataSource>(() => InformationRemoteDataSourceImpl(apiService: Get.find())),
      //Repository
      Bind.lazyPut<InformationRepository>(() => InformationRepositoryImpl(
            remoteDataSource: Get.find(),
          )),
      //Usecase
      Bind.lazyPut(() => ReadInformationUseCase(Get.find())),
    ];
  }
}
