import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/information/presentation/controller/information_controller.dart';
import 'package:dikitis/features/information/presentation/widgets/custom_separator.dart';
import 'package:dikitis/features/information/presentation/widgets/information_list.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InformationPage extends GetView<InformationController> {
  const InformationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.cyan,
      body: BackButtonListener(
        onBackButtonPressed: () {
          if (controller.status.isLoading == false) {
            changeBarColor(statusBarColor: Colors.transparent, navBarColor: AppColors.cyan[700]!);
            Get.back();
          }
          return Future<bool>.value(true);
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomLeft,
              colors: [
                AppColors.cyan[300]!,
                AppColors.cyan[700]!,
              ],
            ),
          ),
          child: Container(
            padding: EdgeInsets.only(top: 10.0.wp, bottom: 0.0.wp),
            margin: EdgeInsets.only(
              left: 5.0.wp,
              right: 5.0.wp,
            ),
            child: Column(
              children: [
                //Header
                CustomCardAnimation(
                  imagePath: ImagePath.information,
                  title: "relatedInfo".tr,
                  description: "",
                  // color: Colors.red,
                ),
                //Separator
                CustomSeparator(
                  color: AppColors.white,
                ),
                //List Information
                Expanded(
                  child: controller.obx(
                    (state) => InformationList(
                      informationList: state,
                    ),
                    onLoading: const CustomLoading(),
                    onEmpty: const CustomEmpty(),
                    onError: (String? error) => CustomError(
                      errorMessage: error.toString(),
                      function: () {
                        controller.onInit();
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
