import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/features/information/domain/entities/information_entity.dart';

abstract class InformationRepository {
  Future<Either<Failure, List<InformationEntity>>> readInformation();
}
