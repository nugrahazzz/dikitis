import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/information/domain/entities/information_entity.dart';
import 'package:dikitis/features/information/domain/repositories/information_repository.dart';

class ReadInformationUseCase implements UseCase<List<InformationEntity>, NoParams> {
  final InformationRepository repository;

  ReadInformationUseCase(this.repository);

  @override
  Future<Either<Failure, List<InformationEntity>>> call(NoParams params) {
    return repository.readInformation();
  }
}
