import 'dart:convert';

import 'package:dikitis/core/constant/api/api_path.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/services/rest_api_service.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dikitis/features/information/data/models/information_model.dart';
import 'package:dikitis/features/information/data/models/information_response.dart';
import 'package:dio/dio.dart';

abstract class InformationRemoteDataSource {
  Future<List<InformationModel>> readInformation();
}

class InformationRemoteDataSourceImpl implements InformationRemoteDataSource {
  final RestApiService apiService;

  InformationRemoteDataSourceImpl({
    required this.apiService,
  });

  @override
  Future<List<InformationModel>> readInformation() async {
    //response
    Response<dynamic> response = await apiService.get(endPoint: ApiPath.readInformation);
    //parsing
    try {
      return InformationResponse.fromJson(json.decode(response.data)).data;
    } catch (e) {
      throw DataSource.parserError.getFailure();
    }
  }
}
