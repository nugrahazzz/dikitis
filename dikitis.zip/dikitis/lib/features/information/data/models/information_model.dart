import 'package:dikitis/features/information/domain/entities/information_entity.dart';

class InformationModel extends InformationEntity {
  const InformationModel({
    required super.id,
    required super.title,
    required super.description,
  });

  factory InformationModel.fromJson(Map<String, dynamic> map) => InformationModel(
        id: map['information_id'] ?? "",
        title: map['information_title'] ?? "",
        description: map['information_description'] ?? "",
      );

  InformationEntity toEntity() {
    return InformationEntity(
      id: id.toString(),
      title: title.toString(),
      description: description.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'information_id': id,
        'information_title': title,
        'information_description': description,
      };
}
