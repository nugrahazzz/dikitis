import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/features/information/data/models/information_model.dart';

class InformationResponse {
  final bool isSuccess;
  final String message;
  final List<InformationModel> data;

  const InformationResponse({
    required this.isSuccess,
    required this.message,
    required this.data,
  });

  factory InformationResponse.fromJson(Map<String, dynamic> json) {
    return InformationResponse(
      isSuccess: (json["is_success"] ?? false).toString().parseToBool(),
      message: json["message"] ?? "",
      data: List<InformationModel>.from(
        (json["data"] as List).map(
          (x) => InformationModel.fromJson(x),
        ),
      ),
    );
  }
}
