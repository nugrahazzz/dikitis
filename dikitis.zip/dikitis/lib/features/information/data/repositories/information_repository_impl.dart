import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/features/information/data/data_source/information_remote_data_source.dart';
import 'package:dikitis/features/information/data/models/information_model.dart';
import 'package:dikitis/features/information/domain/entities/information_entity.dart';
import 'package:dikitis/features/information/domain/repositories/information_repository.dart';

class InformationRepositoryImpl implements InformationRepository {
  final InformationRemoteDataSource remoteDataSource;

  InformationRepositoryImpl({
    required this.remoteDataSource,
  });

  @override
  Future<Either<Failure, List<InformationEntity>>> readInformation() async {
    try {
      final List<InformationModel> result = await remoteDataSource.readInformation();
      return Right(result.map((InformationModel model) => model.toEntity()).toList());
    } catch (error) {
      return Left(ErrorHandler.handle(error).failure);
    }
  }
}
