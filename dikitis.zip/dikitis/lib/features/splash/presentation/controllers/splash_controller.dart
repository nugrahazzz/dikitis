import 'dart:async';

import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/config/translations/localization_translations.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/authentication/domain/usecases/get_is_logged_in.dart';
import 'package:dikitis/features/change_language/domain/usecases/get_locale_language.dart';
import 'package:dikitis/features/onboarding/domain/usecases/check_if_onboarding_viewed.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

class SplashController extends GetxController {
  final CheckIfOnboardingViewedUseCase checkIfOnboardingViewedUseCase;
  final GetIsLoggedInUseCase getIsLoggedInUseCase;
  final GetLocaleLanguageUseCase getLocaleLanguageUseCase;

  SplashController({
    required this.checkIfOnboardingViewedUseCase,
    required this.getIsLoggedInUseCase,
    required this.getLocaleLanguageUseCase,
  });

  final RxBool _isOnboardingViewed = false.obs;
  final RxBool _isLoggedIn = false.obs;

  bool get isOnboardingViewed => _isOnboardingViewed.value;

  bool get isLoggedIn => _isLoggedIn.value;

  @override
  void onInit() {
    super.onInit();
    getInitializeLocale();
    _checkInitialStatuses();
  }

  @override
  void onReady() {
    super.onReady();
    _navigateToNextPage();
  }

  void getInitializeLocale() async {
    final result = await getLocaleLanguageUseCase(NoParams());

    result.fold((failure) {
      showCustomSnackBar(title: failure.message, description: "(error code: ${failure.code})");
    }, (data) {
      LocalizationTranslations.changeLocale(locale: data);
    });
  }

  Future<void> _checkInitialStatuses() async {
    final results = await Future.wait([
      _checkIfFirstOpened(),
      _checkIsLoggedIn(),
    ]);

    _isOnboardingViewed.value = results[0];
    _isLoggedIn.value = results[1];

    Future.delayed(2300.milliseconds, () {
      if (_isOnboardingViewed.value == true && _isLoggedIn.value == true) {
        Get.offAllNamed(Routes.homePage);
      } else if (_isOnboardingViewed.value == true && _isLoggedIn.value == false) {
        Get.offAllNamed(Routes.authenticationPage);
      } else {
        //Do Nothing
      }
    });
  }

  Future<bool> _checkIfFirstOpened() async {
    final result = await checkIfOnboardingViewedUseCase(NoParams());
    return result.fold((failure) {
      showCustomSnackBar(title: "(error code: ${failure.code})", description: failure.message);
      return false;
    }, (bool status) {
      return status;
    });
  }

  Future<bool> _checkIsLoggedIn() async {
    final result = await getIsLoggedInUseCase(NoParams());
    return result.fold((failure) {
      showCustomSnackBar(title: "(error code: ${failure.code})", description: failure.message);
      if (kDebugMode) {
        print(failure.message.toString());
      }
      return false;
    }, (status) => status);
  }

  void _navigateToNextPage() {
    Timer(const Duration(milliseconds: 3300), () {
      if (isOnboardingViewed == true) {
        if (isLoggedIn == true) {
          Get.offAllNamed(Routes.homePage);
        } else {
          Get.offAllNamed(Routes.authenticationPage);
        }
      } else {
        //Do Nothing
      }
    });
  }
}
