import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LegalNoteDialog extends StatefulWidget {
  final String pathUrl;

  const LegalNoteDialog({super.key, required this.pathUrl});

  @override
  State<LegalNoteDialog> createState() => _LegalNoteDialogState();
}

class _LegalNoteDialogState extends State<LegalNoteDialog> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.transparent,
      body: DelayedWidget(
        delayDuration: const Duration(milliseconds: 250),
        animationDuration: const Duration(milliseconds: 500),
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 4.5.wp).copyWith(bottom: 4.0.wp),
            height: 90.0.hp,
            // width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(4.5.wp)),
              color: AppColors.black,
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                //content
                Padding(
                  padding: EdgeInsets.only(bottom: 16.0.wp),
                  child: RawScrollbar(
                    radius: Radius.circular(2.0.wp),
                    thumbColor: AppColors.cyan.withValues(alpha: 0.5),
                    mainAxisMargin: 2.5.wp,
                    crossAxisMargin: 1.25.wp,
                    thumbVisibility: true,
                    trackVisibility: true,
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: HTMLViewer(
                        path: widget.pathUrl,
                        textColor: AppColors.white,
                      ),
                    ),
                  ),
                ),
                //button
                Positioned(
                    right: 4.0.wp,
                    left: 4.0.wp,
                    bottom: 4.0.wp,
                    child: CustomButton(
                      height: 12.5.wp,
                      title: "Okay",
                      titleColor: AppColors.bgDark,
                      onlyIcon: false,
                      function: () {
                        Get.backLegacy();
                      },
                      color: AppColors.cyan,
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
