import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/html_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/features/splash/presentation/views/component/legal_note_dialog.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class IntroduceDialog extends StatefulWidget {
  const IntroduceDialog({super.key});

  @override
  State<IntroduceDialog> createState() => _IntroduceDialogState();
}

class _IntroduceDialogState extends State<IntroduceDialog> {
  // PermissionController permissionController = PermissionController.to;

  @override
  Widget build(BuildContext context) {
    return DelayedWidget(
      delayDuration: const Duration(milliseconds: 1300),
      animationDuration: const Duration(milliseconds: 500),
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.0.wp),
        color: AppColors.bgDark,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "welcomeIntro".tr,
              textAlign: TextAlign.center,
              style: AppTextStyles.poppinsBold.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                wordSpacing: 0.2,
                fontSize: 5.3.wp,
              ),
            ),
            SizedBox(
              height: 2.0.wp,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 1.0.wp),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "readOur".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: " ",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                      ),
                    ),
                    TextSpan(
                      text: "privacyPolicy".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 3.5.wp,
                        color: AppColors.cyan,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () => Get.dialog(
                              LegalNoteDialog(
                                pathUrl: HtmlPath.privacyPolicy,
                              ),
                              barrierDismissible: false,
                              barrierColor: Colors.transparent,
                            ),
                    ),
                    TextSpan(
                      text: ", ",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: "requiredPermission".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 3.5.wp,
                        color: AppColors.cyan,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () => Get.dialog(
                              LegalNoteDialog(
                                pathUrl: HtmlPath.requiredPermission,
                              ),
                              barrierDismissible: false,
                              barrierColor: Colors.transparent,
                            ),
                    ),
                    TextSpan(
                      text: ", ",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: "and".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: " ",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: "termOfUser".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 3.5.wp,
                        color: AppColors.cyan,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () => Get.dialog(
                              LegalNoteDialog(
                                pathUrl: HtmlPath.termOfUser,
                              ),
                              barrierDismissible: false,
                              barrierColor: Colors.transparent,
                            ),
                    ),
                    TextSpan(
                      text: ". ",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: "tapAgree".tr,
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                    TextSpan(
                      text: ".",
                      style: AppTextStyles.poppinsMedium.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 3.5.wp,
                        letterSpacing: 0,
                        wordSpacing: 0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10.0.wp,
            ),
            CustomButton(
              borderRadius: 3.0.wp,
              function: () {
                Get.offAndToNamed(Routes.onboardingPage);
              },
              title: "agreeAndContinue".tr,
              color: AppColors.white,
              titleColor: AppColors.bgDark,
            ),
          ],
        ),
      ),
    );
  }
}
