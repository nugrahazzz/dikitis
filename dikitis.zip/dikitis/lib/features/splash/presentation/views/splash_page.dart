import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/splash/presentation/controllers/splash_controller.dart';
import 'package:dikitis/features/splash/presentation/views/component/introduce_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class SplashPage extends GetView<SplashController> {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    changeBarColor(
      statusBarColor: AppColors.transparent,
      navBarColor: AppColors.bgDark,
    );
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: Stack(
        children: [
          SizedBox(
            height: Get.height,
            width: Get.width,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 2.0.wp),
              child: Obx(
                () => SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 15.0.wp,
                      ),
                      Container(
                        height: 50.0.wp,
                        padding: EdgeInsets.only(bottom: 4.0.wp),
                        child: Lottie.asset(
                          LottiePath.medicalBag,
                          reverse: false,
                          repeat: false,
                          fit: BoxFit.cover,
                        ),
                      ),
                      controller.isOnboardingViewed == false
                          ? const IntroduceDialog()
                          : DelayedWidget(
                              delayDuration: const Duration(milliseconds: 800),
                              animationDuration: const Duration(milliseconds: 400),
                              child: Text(
                                "dikitisApp".tr,
                                style: AppTextStyles.poppinsBold.copyWith(
                                    color: AppColors.white, fontWeight: FontWeight.bold, letterSpacing: 2, wordSpacing: 0.2, fontSize: 5.5.wp),
                              ),
                            ),
                      SizedBox(
                        height: controller.isOnboardingViewed == false ? 0.0.wp : 30.0.wp,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 5.0.wp,
            right: 0,
            left: 0,
            child: Center(
              child: DelayedWidget(
                delayDuration: const Duration(milliseconds: 1500),
                animationDuration: const Duration(milliseconds: 500),
                child: controller.isOnboardingViewed == false
                    ? GestureDetector(
                        onTap: () {
                          Get.toNamed(Routes.selectLanguagePage);
                        },
                        child: Container(
                          color: Colors.transparent,
                          child: SingleChildScrollView(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "[   ",
                                  style: AppTextStyles.poppinsMedium.copyWith(color: AppColors.white, fontSize: 3.5.wp),
                                ),
                                Text(
                                  "changeLanguage".tr,
                                  textAlign: TextAlign.center,
                                  style: AppTextStyles.poppinsMedium.copyWith(color: AppColors.white, fontSize: 3.5.wp),
                                ),
                                Text(
                                  "  ",
                                  style: AppTextStyles.poppinsMedium.copyWith(color: AppColors.white, fontSize: 3.5.wp),
                                ),
                                Icon(
                                  Icons.language,
                                  color: AppColors.white,
                                  size: 5.0.wp,
                                ),
                                Text(
                                  "   ]",
                                  style: AppTextStyles.poppinsMedium.copyWith(color: AppColors.white, fontSize: 3.5.wp),
                                ),
                              ],
                            ),
                          ),
                        ),
                      )
                    : Text(
                        "Ver 1.2.0",
                        style: AppTextStyles.poppinsSemiBold
                            .copyWith(color: AppColors.white, fontSize: 3.5.wp, fontWeight: FontWeight.w400, letterSpacing: 1.2),
                      ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
