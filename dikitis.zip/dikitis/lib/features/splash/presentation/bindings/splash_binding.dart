import 'package:dikitis/features/authentication/data/data_source/authentication_local_data_source.dart';
import 'package:dikitis/features/authentication/data/data_source/authentication_remote_data_source.dart';
import 'package:dikitis/features/authentication/data/repositories/authentication_repository_impl.dart';
import 'package:dikitis/features/authentication/domain/repositories/authentication_repository.dart';
import 'package:dikitis/features/authentication/domain/usecases/get_is_logged_in.dart';
import 'package:dikitis/features/change_language/domain/usecases/get_locale_language.dart';
import 'package:dikitis/features/legal_note/presentation/controllers/legal_note_controller.dart';
import 'package:dikitis/features/onboarding/data/data_source/onboarding_local_data_source.dart';
import 'package:dikitis/features/onboarding/data/repositories/onboarding_repository_impl.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';
import 'package:dikitis/features/onboarding/domain/usecases/check_if_onboarding_viewed.dart';
import 'package:dikitis/features/splash/presentation/controllers/splash_controller.dart';
import 'package:get/get.dart';

class SplashBinding extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      // Data Sources
      Bind.lazyPut<OnboardingLocalDataSource>(
        () => OnboardingLocalDataSourceImpl(
          databaseService: Get.find(),
        ),
      ),
      Bind.lazyPut<AuthenticationLocalDataSource>(
        () => AuthenticationLocalDataSourceImpl(
          databaseService: Get.find(),
        ),
      ),
      Bind.lazyPut<AuthenticationRemoteDataSource>(
        () => AuthenticationRemoteDataSourceImpl(
          apiService: Get.find(),
        ),
      ),

      // Repositories
      Bind.lazyPut<OnboardingRepository>(
        () => OnboardingRepositoryImpl(
          localDataSource: Get.find(),
        ),
      ),
      Bind.lazyPut<AuthenticationRepository>(
        () => AuthenticationRepositoryImpl(
          localDataSource: Get.find(),
          remoteDataSource: Get.find(),
        ),
      ),

      // Use Cases
      Bind.lazyPut(() => CheckIfOnboardingViewedUseCase(Get.find())),
      Bind.lazyPut(() => GetIsLoggedInUseCase(Get.find())),
      Bind.lazyPut(() => GetLocaleLanguageUseCase(Get.find())),

      // Controllers
      Bind.put<SplashController>(
        SplashController(
          checkIfOnboardingViewedUseCase: Get.find(),
          getIsLoggedInUseCase: Get.find(),
          getLocaleLanguageUseCase: Get.find(),
        ),
      ),
      // Bind.lazyPut<PermissionController>(() => PermissionController()),
      Bind.lazyPut<LegalNoteController>(() => LegalNoteController()),
    ];
  }
}
