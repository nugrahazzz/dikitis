import 'package:auto_size_text/auto_size_text.dart';
import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/document_path.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class FeatureIntroductionPage extends StatefulWidget {
  const FeatureIntroductionPage({super.key});

  @override
  State<FeatureIntroductionPage> createState() => _FeatureIntroductionPageState();
}

class _FeatureIntroductionPageState extends State<FeatureIntroductionPage> {
  // final

  @override
  void initState() {
    super.initState();
    changeBarColor(
      statusBarColor: AppColors.transparent,
      navBarColor: AppColors.bgDark,
    );
  }

  @override
  Widget build(BuildContext context) {
    return BackButtonListener(
      onBackButtonPressed: () {
        Get.back();
        Future.delayed(const Duration(milliseconds: 300), () {
          changeBarColor(
            statusBarColor: AppColors.transparent,
            navBarColor: AppColors.cyan[700]!,
          );
        });

        return Future<bool>.value(true);
      },
      child: Scaffold(
        backgroundColor: AppColors.bgDark,
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 6.0.wp).copyWith(top: 11.0.wp),
          child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(bottom: 6.5.wp),
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Divider(
                        height: 2,
                        color: AppColors.white,
                      ),
                    ),
                    Expanded(
                      flex: 6,
                      child: Center(
                        child: Text(
                          "howToUse".tr,
                          style: AppTextStyles.poppinsBold.copyWith(
                            color: AppColors.white,
                            fontSize: 5.5.wp,
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Divider(
                        height: 2,
                        color: AppColors.white,
                      ),
                    ),
                  ],
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 500),
                child: ListItem(
                  isNavigate: true,
                  icon: Icons.minimize_rounded,
                  text: "howToDiagnose".tr,
                  function: () {
                    Get.to(() => PDFView(path: DocumentPath.diagnosis));
                  },
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 750),
                child: ListItem(
                  isNavigate: true,
                  icon: Icons.minimize_rounded,
                  text: "howToViewDiagnosticHistory".tr,
                  function: () {
                    Get.to(() => PDFView(path: DocumentPath.history));
                  },
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1000),
                child: ListItem(
                  isNavigate: true,
                  icon: Icons.minimize_rounded,
                  text: "howToViewInformation".tr,
                  function: () {
                    Get.to(() => PDFView(path: DocumentPath.information));
                  },
                ),
              ),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1250),
                child: ListItem(
                  isNavigate: true,
                  icon: Icons.minimize_rounded,
                  text: "howToConsult".tr,
                  function: () {
                    Get.to(() => PDFView(path: DocumentPath.consultation));
                  },
                ),
              ),
              const Spacer(),
              DelayedWidget(
                delayDuration: const Duration(milliseconds: 1750),
                child: GestureDetector(
                  onTap: () => Get.offNamed(Routes.feedbackPage),
                  child: Container(
                    margin: EdgeInsets.only(
                      bottom: 5.0.wp,
                    ),
                    padding: EdgeInsets.only(left: 4.0.wp).copyWith(top: 3.0.wp, bottom: 3.0.wp, right: 2.5.wp),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: AppColors.white,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: AutoSizeText(
                            "cantFindInformation".tr,
                            textAlign: TextAlign.justify,
                            maxLines: 2,
                            style: AppTextStyles.poppinsSemiBold.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.bgDark.withValues(alpha: 0.95),
                              height: 1.6,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 4.0.wp,
                        ),
                        SizedBox(
                          width: 16.0.wp,
                          child: Lottie.asset(
                            LottiePath.searching,
                            repeat: true,
                            animate: true,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
