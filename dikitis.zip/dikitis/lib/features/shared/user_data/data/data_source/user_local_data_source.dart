import 'package:dikitis/core/services/database_service.dart';

abstract class UserLocalDataSource {
  Future<void> setUserData(String userJson);

  Future<void> getUserData(String userJson);
}

class UserLocalDataSourceImpl implements UserLocalDataSource {
  final DatabaseService databaseService;

  UserLocalDataSourceImpl({required this.databaseService});

  // final String _isLoggedKey = "isLoggedKey";
  final String _userKey = "userKey";

  @override
  Future<void> setUserData(String userJson) async {
    await databaseService.write(_userKey, userJson);
  }

  @override
  Future<void> getUserData(String userJson) {
    // TODO: implement getUserData
    throw UnimplementedError();
  }
}
