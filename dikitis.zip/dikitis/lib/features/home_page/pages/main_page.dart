import 'package:delayed_widget/delayed_widget.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/home_page/controller/home_controller.dart';
import 'package:dikitis/features/home_page/widgets/custom_drawer.dart';
import 'package:double_back_to_close/double_back_to_close.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  // This widget is the root of your application.
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final HomeController _mainController = HomeController.to;

  @override
  void initState() {
    changeBarColor(
      statusBarColor: Colors.transparent,
      navBarColor: AppColors.cyan[700]!,
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DoubleBack(
        onFirstBackPress: (context) {
          // localStorageController.readData();
          showCustomSnackBar(title: "pressMore", description: "toLeave");
        },
        waitForSecondBackPress: 3,
        child: Stack(
          children: [
            const CustomDrawer(),
            Obx(
              () => AnimatedContainer(
                  transform: Matrix4.translationValues(_mainController.xOffset, _mainController.yOffset, 0)
                    ..scale(_mainController.getDrawerIsOpen ? 0.85 : 1.00)
                    ..rotateZ(_mainController.getDrawerIsOpen ? -50 : 0),
                  duration: const Duration(milliseconds: 230),
                  decoration: BoxDecoration(
                    borderRadius: _mainController.getDrawerIsOpen ? BorderRadius.circular(24) : BorderRadius.circular(0),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        AppColors.cyan[300]!,
                        AppColors.cyan[700]!,
                      ],
                    ),
                  ),
                  child: Container(
                    margin: EdgeInsets.only(
                      top: 4.0.wp,
                      left: 6.0.wp,
                      right: 6.0.wp,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: ListView(
                            children: [
                              //profile
                              Container(
                                margin: EdgeInsets.only(
                                  bottom: 3.0.wp,
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.white,
                                  borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(4.0.wp),
                                    bottomLeft: Radius.circular(4.0.wp),
                                    topLeft: Radius.circular(4.0.wp),
                                    topRight: Radius.circular(4.0.wp),
                                  ),
                                ),
                                child: Stack(
                                  children: [
                                    //image x fullname
                                    Container(
                                      padding: EdgeInsets.all(5.0.wp),
                                      child: Row(
                                        children: [
                                          photoProfile(size: 20.0.wp, color: AppColors.cyan),
                                          SizedBox(
                                            width: 4.5.wp,
                                          ),
                                          Expanded(
                                            child: Container(
                                              padding: EdgeInsets.symmetric(vertical: 5.0.wp),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Container(
                                                    color: Colors.transparent,
                                                    padding: EdgeInsets.only(bottom: 0.2.wp),
                                                    child: Text(
                                                      "${"welcome".tr},",
                                                      textAlign: TextAlign.start,
                                                      maxLines: 1,
                                                      overflow: TextOverflow.ellipsis,
                                                      style: AppTextStyles.poppinsMedium.copyWith(
                                                        fontWeight: FontWeight.bold,
                                                        fontSize: 3.8.wp,
                                                        letterSpacing: 0.5,
                                                        color: AppColors.bgDark.withValues(alpha: 0.8),
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    // LocalLocalStorageServices().getFullname(),
                                                    "xxx",
                                                    textAlign: TextAlign.start,
                                                    overflow: TextOverflow.clip,
                                                    maxLines: 1,
                                                    style: AppTextStyles.poppinsBold.copyWith(
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 5.2.wp,
                                                      letterSpacing: 0.3,
                                                      color: AppColors.bgDark.withValues(alpha: 0.8),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    //menu three dot
                                    Positioned(
                                      top: -19.0.wp,
                                      left: 0,
                                      right: -87.0.wp,
                                      child: GestureDetector(
                                        onTap: () {
                                          Get.toNamed(Routes.settingPage);
                                        },
                                        child: Container(
                                          height: 35.0.wp,
                                          decoration: BoxDecoration(color: AppColors.cyan.withValues(alpha: 0.125), shape: BoxShape.circle),
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                              top: 16.0.wp,
                                              right: 11.0.wp,
                                            ),
                                            child: Icon(
                                              // Icons.more_vert_outlined,
                                              Icons.edit_note,
                                              color: AppColors.cyan,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                // FutureBuilder(
                                //     future: _mainController.getUserData(),
                                //     builder: (context, snapshot) {
                                //       // jika sudah ada data
                                //       return Stack(
                                //         children: [
                                //           //image x fullname
                                //           Container(
                                //             padding: EdgeInsets.all(5.0.wp),
                                //             child: Row(
                                //               children: [
                                //                 photoProfile(size: 20.0.wp, color: Colors.cxyan.withValues(alpha: 0.75)),
                                //                 SizedBox(
                                //                   width: 4.5.wp,
                                //                 ),
                                //                 Expanded(
                                //                   child: Container(
                                //                     padding: EdgeInsets.symmetric(vertical: 5.0.wp),
                                //                     child: Column(
                                //                       crossAxisAlignment: CrossAxisAlignment.start,
                                //                       children: <Widget>[
                                //                         Container(
                                //                           color: Colors.transparent,
                                //                           padding: EdgeInsets.only(bottom: 0.2.wp),
                                //                           child: Text(
                                //                             "Selamat datang,",
                                //                             textAlign: TextAlign.start,
                                //                             maxLines: 1,
                                //                             overflow: TextOverflow.ellipsis,
                                //                             style: TextStyles.poppinsMedium.copyWith(
                                //                               fontWeight: FontWeight.bold,
                                //                               fontSize: 3.8.wp,
                                //                               letterSpacing: 0.5,
                                //                               color: ColorManager.bgDark.withValues(alpha: 0.8),
                                //                             ),
                                //                           ),
                                //                         ),
                                //                         Text(
                                //                           LocalLocalStorageServices().getFullname(),
                                //                           textAlign: TextAlign.start,
                                //                           overflow: TextOverflow.clip,
                                //                           maxLines: 1,
                                //                           style: TextStyles.poppinsBold.copyWith(
                                //                             fontWeight: FontWeight.w600,
                                //                             fontSize: 5.2.wp,
                                //                             letterSpacing: 0.3,
                                //                             color: ColorManager.bgDark.withValues(alpha: 0.8),
                                //                           ),
                                //                         ),
                                //                       ],
                                //                     ),
                                //                   ),
                                //                 ),
                                //               ],
                                //             ),
                                //           ),
                                //           //menu three dot
                                //           Positioned(
                                //             top: -19.0.wp,
                                //             left: 0,
                                //             right: -87.0.wp,
                                //             child: GestureDetector(
                                //               onTap: () {
                                //                 Get.toNamed(Routes.settingPage);
                                //               },
                                //               child: Container(
                                //                 height: 35.0.wp,
                                //                 decoration: BoxDecoration(color: ColorManager.cyan.withValues(alpha: 0.125), shape: BoxShape.circle),
                                //                 child: Padding(
                                //                   padding: EdgeInsets.only(
                                //                     top: 16.0.wp,
                                //                     right: 11.0.wp,
                                //                   ),
                                //                   child: Icon(
                                //                     Icons.more_vert_outlined,
                                //                     color: ColorManager.cyan,
                                //                   ),
                                //                 ),
                                //               ),
                                //             ),
                                //           ),
                                //         ],
                                //       );
                                //     }),
                              ),

                              //divider
                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 1.1.wp),
                                child: Divider(
                                  thickness: 1,
                                  color: AppColors.white,
                                ),
                              ),
                              //content
                              DelayedWidget(
                                delayDuration: const Duration(milliseconds: 300), // Not required
                                animationDuration: const Duration(milliseconds: 600), // Not required
                                animation: DelayedAnimations.SLIDE_FROM_TOP,
                                child: CustomCardAnimation(
                                  imagePath: ImagePath.information,
                                  title: "knowPsychosomatic".tr,
                                  description: "knowPsychosomaticDesc".tr,
                                  function: () {
                                    checkConnectionBeforeExecute(
                                      function: () {
                                        Get.toNamed(
                                          Routes.informationPage,
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                              DelayedWidget(
                                delayDuration: const Duration(milliseconds: 600), // Not required
                                animationDuration: const Duration(milliseconds: 600), // Not required
                                animation: DelayedAnimations.SLIDE_FROM_TOP,
                                child: CustomCardAnimation(
                                  imagePath: ImagePath.diagnosis,
                                  title: "diagnosisNow".tr,
                                  description: "diagnosisNowDesc".tr,
                                  function: () {
                                    Get.toNamed(Routes.diagnosisPage);
                                  },
                                ),
                              ),
                              DelayedWidget(
                                delayDuration: const Duration(milliseconds: 900), // Not required
                                animationDuration: const Duration(milliseconds: 600), // Not required
                                animation: DelayedAnimations.SLIDE_FROM_TOP,
                                child: CustomCardAnimation(
                                  imagePath: ImagePath.messaging,
                                  title: "consultationNow".tr,
                                  description: "consultationNowDesc".tr,
                                  function: () {
                                    Get.toNamed(Routes.doctorAvailablePage);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                        DelayedWidget(
                          delayDuration: const Duration(milliseconds: 1200),
                          animationDuration: const Duration(seconds: 1),
                          animation: DelayedAnimations.SLIDE_FROM_BOTTOM,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: GestureDetector(
                              onTap: () {
                                if (_mainController.getDrawerIsOpen == true) {
                                  _mainController.drawerIsOpen(false, Colors.transparent, AppColors.cyan[700]!);
                                } else {
                                  _mainController.drawerIsOpen(
                                    true,
                                    Colors.transparent,
                                    AppColors.bgDark,
                                  );
                                }
                              },
                              child: Container(
                                margin: EdgeInsets.only(bottom: 7.5.wp),
                                padding: EdgeInsets.all(3.0.wp),
                                // height: 15.0.wp,
                                decoration: BoxDecoration(color: AppColors.bgDark.withValues(alpha: 0.9), shape: BoxShape.circle),
                                child: Icon(
                                  _mainController.getDrawerIsOpen == false ? Icons.menu : Icons.close_sharp,
                                  color: AppColors.white,
                                  size: 9.0.wp,
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }

  Widget photoProfile({required double size, required Color color}) {
    return Stack(
      children: [
        // kanan atas
        Positioned(
          top: 0,
          right: 0,
          child: Container(
            height: size / 4,
            width: size / 4,
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(
                Radius.circular(12),
              ),
              shape: BoxShape.rectangle,
            ),
          ),
        ),
        // kiri bawah
        Positioned(
          top: 0,
          left: 0,
          child: Container(
            height: size / 4,
            width: size / 4,
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(
                Radius.circular(12),
              ),
              shape: BoxShape.rectangle,
            ),
          ),
        ),
        // kiri bawah
        Positioned(
          bottom: 0,
          left: 0,
          child: Container(
            height: size / 4,
            width: size / 4,
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(
                Radius.circular(12),
              ),
              shape: BoxShape.rectangle,
            ),
          ),
        ),

        // kanan bawah
        Positioned(
          bottom: 0,
          right: 0,
          child: Container(
            height: size / 4,
            width: size / 4,
            decoration: BoxDecoration(
              color: color,
              borderRadius: const BorderRadius.all(
                Radius.circular(12),
              ),
              shape: BoxShape.rectangle,
            ),
          ),
        ),
        //
        Container(
          height: size,
          width: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.transparent,
            border: Border.all(width: size / 100, color: AppColors.cyan, style: BorderStyle.solid),
          ),
          child:
              //(LocalLocalStorageServices().getPhotoUrl().toString()
              ("" == "")
                  ? Container(
                      decoration: BoxDecoration(color: AppColors.white, shape: BoxShape.circle),
                      child: Icon(
                        Icons.face,
                        color: AppColors.cyan,
                        size: size / 2,
                      ))

                  //image
                  : ExtendedImage.network(
                      // "${ApiPath.imageStorage}${LocalLocalStorageServices().getPhotoUrl()}",
                      "xxx",
                      fit: BoxFit.fill,
                      border: Border.all(color: AppColors.cyan, width: 1.0),
                      shape: BoxShape.circle,
                      cache: false,
                      cacheRawData: false,
                      clearMemoryCacheIfFailed: true,
                      clearMemoryCacheWhenDispose: true,
                      loadStateChanged: (ExtendedImageState state) {
                        switch (state.extendedImageLoadState) {
                          case LoadState.loading:
                            return SpinKitWave(
                              size: 3.0.wp,
                              color: AppColors.cyan,
                            );

                          case LoadState.completed:
                            return GestureDetector(
                              onTap: () {
                                // debugPrint(
                                //   "${ApiPath.imageStorage}${LocalLocalStorageServices().getPhotoUrl()}",
                                // );
                              },
                              child: Container(
                                decoration: BoxDecoration(color: AppColors.white, shape: BoxShape.circle),
                                child: ExtendedRawImage(
                                  image: state.extendedImageInfo?.image,
                                ),
                              ),
                            );

                          case LoadState.failed:
                            return GestureDetector(
                              child: Center(
                                child: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 2.0.wp),
                                  child: Text(
                                    "Load failed",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan),
                                  ),
                                ),
                              ),
                              onTap: () {
                                state.reLoadImage();
                                if (kDebugMode) {
                                  // print(
                                  //   "${ApiPath.imageStorage}${LocalLocalStorageServices().getPhotoUrl()}",
                                  // );
                                }
                              },
                            );
                        }
                      },
                      borderRadius: const BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                    ),
        ),
      ],
    );
  }
}
