import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  static HomeController to = Get.find<HomeController>();

  // final DiagnosticReportController diagnosisHistoryController = Get.find<DiagnosticReportController>();

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    //melihat list diagnosis pasien
    // diagnosisHistoryController.readC();
  }

  double xOffset = 0;
  double yOffset = 0;

  final RxBool _isDrawerOpen = false.obs;

  //getter isDrawerOpen
  bool get getDrawerIsOpen => _isDrawerOpen.value;

  //setter isDrawerOpen
  set setDrawerIsOpen(bool isDrawerOpen) {
    _isDrawerOpen.value = isDrawerOpen;
  }

  void drawerIsOpen(bool status, Color statusColor, Color navColor) {
    setDrawerIsOpen = status;
    if (getDrawerIsOpen == false) {
      xOffset = 0;
      yOffset = 0;
    } else {
      xOffset = 72.5.wp;
      yOffset = 11.0.hp;
    }

    changeBarColor(statusBarColor: statusColor, navBarColor: navColor);
  }
}
