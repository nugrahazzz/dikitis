import 'package:dikitis/features/home_page/controller/home_controller.dart';
import 'package:get/get.dart';

class HomeBinding implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<HomeController>(() => HomeController()),
    ];
    // Get.lazyPut<DiagnosticReportController>(() => DiagnosticReportController());
  }
}
