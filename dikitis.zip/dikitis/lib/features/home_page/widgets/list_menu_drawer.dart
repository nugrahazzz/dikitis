import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:flutter/material.dart';

class ListMenuDrawer extends StatelessWidget {
  final IconData icon;
  final String text;
  final Function()? function;

  const ListMenuDrawer({
    super.key,
    this.icon = Icons.error,
    this.text = "",
    this.function,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: function,
      child: Container(
        color: Colors.transparent,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Icon(
              icon,
              color: AppColors.white,
              size: 6.75.wp,
            ),
            SizedBox(
              width: 3.5.wp,
            ),
            Text(
              text,
              style: TextStyle(color: AppColors.white, fontWeight: FontWeight.w500, fontSize: 4.0.wp),
            )
          ],
        ),
      ),
    );
  }
}
