import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AboutDialogs extends StatefulWidget {
  const AboutDialogs({super.key});

  @override
  State<AboutDialogs> createState() => _AboutDialogsState();
}

class _AboutDialogsState extends State<AboutDialogs> {
  double padding = 5.0.wp;
  double avatarRadius = 15.0.wp;

  @override
  void initState() {
    super.initState();
    changeBarColor(statusBarColor: Colors.transparent, navBarColor: AppColors.bgDark);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.only(
              top: avatarRadius,
              left: padding * 3 / 2,
              right: padding * 3 / 2,
            ),
            margin: EdgeInsets.only(top: avatarRadius),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.circular(padding),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 10.0,
                  offset: Offset(0.0, 10.0),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min, // To make the card compact
              children: <Widget>[
                Text(
                  "aboutApp".tr,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 5.5.wp,
                    fontWeight: FontWeight.w900,
                    color: AppColors.bgDark.withValues(alpha: 0.9),
                  ),
                ),
                SizedBox(height: 4.5.wp),
                RichText(
                  textAlign: TextAlign.justify,
                  text: TextSpan(
                      style: AppTextStyles.poppinsMedium.copyWith(
                        color: AppColors.bgDark.withValues(alpha: 0.8),
                        fontWeight: FontWeight.w500,
                        fontSize: 3.3.wp,
                        letterSpacing: 0,
                        height: 1.3,
                      ),
                      children: [
                        TextSpan(
                          text: "app".tr,
                        ),
                        TextSpan(
                          text: " Dikitis ",
                          style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.bgDark),
                        ),
                        TextSpan(
                          text: "${"aboutDesc1".tr} ",
                        ),
                        TextSpan(
                          text: "Agung Nugraha",
                          style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.bgDark),
                        ),
                        TextSpan(
                          text: " ${"aboutDesc2".tr} ",
                        ),
                        TextSpan(
                          text: "Dr. Kemas Muhammad Yunus, M.M.",
                          style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.bgDark),
                        ),
                      ]),
                ),
                SizedBox(height: 4.5.wp),
                CustomButton(
                    onlyIcon: false,
                    width: double.infinity,
                    borderRadius: 12,
                    height: 15.0.wp,
                    color: AppColors.bgDark,
                    title: "readMore".tr,
                    fontSize: 4.25.wp,
                    titleColor: AppColors.white,
                    function: () {
                      Get.offNamed(Routes.aboutPage);
                    }),
                //
                SizedBox(height: 7.0.wp),
              ],
            ),
          ),
          //Gambar
          Positioned.fill(
            child: Align(
              alignment: Alignment.topCenter,
              child: ClipOval(
                child: Container(
                  color: AppColors.white,
                  height: 30.0.wp,
                  width: 30.0.wp,
                  child: Image.asset(
                    ImagePath.campusLogo,
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
