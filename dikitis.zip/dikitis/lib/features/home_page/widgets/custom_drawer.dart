import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/constant/assets/lottie_path.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/home_page/controller/home_controller.dart';
import 'package:dikitis/features/home_page/widgets/about_dialog.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'list_menu_drawer.dart';

class CustomDrawer extends StatefulWidget {
  const CustomDrawer({super.key});

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  final HomeController _mainController = HomeController.to;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.bgDark,
      padding: EdgeInsets.only(left: 4.5.wp, bottom: 20.0.wp),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          ListMenuDrawer(
            text: "tutorial".tr,
            icon: Icons.help_outline_sharp,
            function: () {
              if (_mainController.getDrawerIsOpen == true) {
                _mainController.drawerIsOpen(false, Colors.transparent, AppColors.cyan[700]!);
              }

              Future.delayed(const Duration(milliseconds: 300), () {
                Get.toNamed(Routes.featureIntroductionPage);
              });
            },
          ),
          SizedBox(
            height: 5.9.wp,
          ),
          ListMenuDrawer(
            text: "suggestions".tr,
            icon: Icons.description_outlined,
            function: () {
              if (_mainController.getDrawerIsOpen == true) {
                _mainController.drawerIsOpen(false, Colors.transparent, AppColors.cyan);
              }

              Future.delayed(const Duration(milliseconds: 300), () {
                Get.toNamed(Routes.feedbackPage);
              });
            },
          ),
          SizedBox(
            height: 3.7.wp,
          ),
          Divider(
            color: AppColors.white,
          ),
          SizedBox(
            height: 3.7.wp,
          ),
          ListMenuDrawer(
            text: "settings".tr,
            icon: Icons.settings,
            function: () {
              if (_mainController.getDrawerIsOpen == true) {
                _mainController.drawerIsOpen(false, Colors.transparent, AppColors.cyan);
              }

              Future.delayed(const Duration(milliseconds: 300), () {
                Get.toNamed(Routes.settingPage);
              });
            },
          ),
          SizedBox(
            height: 5.9.wp,
          ),
          ListMenuDrawer(
            text: "about".tr,
            icon: Icons.info_outline_rounded,
            function: () {
              Get.dialog(const AboutDialogs(), barrierDismissible: true, barrierColor: AppColors.bgDark.withValues(alpha: 0.33));
            },
          ),
          SizedBox(
            height: 5.9.wp,
          ),
          ListMenuDrawer(
            text: "logout".tr,
            icon: Icons.logout_sharp,
            function: () {
              showCustomDialog(
                title: 'Keluar',
                description: "Hai, ${"LocalLocalStorageServices().getFullname()"}. Apakah Anda ingin meninggalkan akun ini?",
                function: () {
                  // LocalLocalStorageServices().clearUserData().then((_) {
                  //   Get.delete<MainController>();
                  Get.offAllNamed(Routes.authenticationPage);
                  // });

                  if (_mainController.getDrawerIsOpen == true) {
                    _mainController.drawerIsOpen(false, Colors.transparent, AppColors.bgDark);
                  }
                },
                buttonText: "logout".tr,
                imagePath: LottiePath.exit,
                colorStatusBar: Colors.transparent,
                colorNavigationBar: AppColors.bgDark,
              );
            },
          ),
          SizedBox(
            height: 5.9.wp,
          ),
        ],
      ),
    );
  }
}
