import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';

class OnboardingModel extends Onboarding {
  OnboardingModel({
    required super.imageAsset,
    required super.title,
    required super.description,
  });

  factory OnboardingModel.fromJson(Map<String, dynamic> json) {
    return OnboardingModel(
      imageAsset: json['imageAsset'],
      title: json['title'],
      description: json['description'],
    );
  }

  Onboarding toEntity() {
    return Onboarding(
      imageAsset: imageAsset.toString(),
      title: title.toString(),
      description: description.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'imageAsset': imageAsset,
      'title': title,
      'description': description,
    };
  }
}
