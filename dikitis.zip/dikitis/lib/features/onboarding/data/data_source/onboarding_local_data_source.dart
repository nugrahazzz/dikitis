import 'package:dikitis/core/constant/assets/image_path.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/services/database_service.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dikitis/features/onboarding/data/models/onboarding_model.dart';
import 'package:get/get.dart';

abstract class OnboardingLocalDataSource {
  Future<List<OnboardingModel>> getOnboardingData();

  Future<bool> checkIfOnboardingViewed();

  Future<void> setOnboardingViewed(bool status);
}

class OnboardingLocalDataSourceImpl implements OnboardingLocalDataSource {
  final DatabaseService databaseService;

  OnboardingLocalDataSourceImpl({required this.databaseService});

  final String _onboardingKey = "onboardingKey";

  @override
  Future<List<OnboardingModel>> getOnboardingData() async {
    try {
      return [
        OnboardingModel(
          imageAsset: ImagePath.observation,
          title: "knowPsychosomatic".tr,
          description: 'knowPsychosomaticDesc'.tr,
        ),
        OnboardingModel(
          imageAsset: ImagePath.selfDiagnosis,
          title: "doDiagnosis".tr,
          description: "doDiagnosisDesc".tr,
        ),
        OnboardingModel(
          imageAsset: ImagePath.chat,
          title: 'furtherConsultation'.tr,
          description: 'furtherConsultationDesc'.tr,
        ),
      ];
    } catch (e) {
      throw DataSource.cacheError.getFailure();
    }
  }

  @override
  Future<bool> checkIfOnboardingViewed() async {
    bool status = await databaseService.read(_onboardingKey) ?? false;
    return status;
  }

  @override
  Future<void> setOnboardingViewed(bool status) async {
    databaseService.write(_onboardingKey, status);
  }
}
