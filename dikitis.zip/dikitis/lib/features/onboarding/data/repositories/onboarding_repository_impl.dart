import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/error_handler.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/enums/data_source.dart';
import 'package:dikitis/features/onboarding/data/data_source/onboarding_local_data_source.dart';
import 'package:dikitis/features/onboarding/data/models/onboarding_model.dart';
import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';

class OnboardingRepositoryImpl implements OnboardingRepository {
  final OnboardingLocalDataSource localDataSource;

  OnboardingRepositoryImpl({required this.localDataSource});

  @override
  Future<Either<Failure, List<Onboarding>>> getOnboardingInfo() async {
    try {
      final List<OnboardingModel> result = await localDataSource.getOnboardingData();
      return Right(result.map((OnboardingModel model) => model.toEntity()).toList());
    } catch (error) {
      return Left(ErrorHandler.handle(error).failure);
    }
  }

  @override
  Future<Either<Failure, bool>> checkIfOnboardingViewed() async {
    try {
      final result = await localDataSource.checkIfOnboardingViewed();
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }

  @override
  Future<Either<Failure, void>> setOnboardingViewed(bool status) async {
    try {
      final result = await localDataSource.setOnboardingViewed(status);
      return Right(result);
    } catch (error) {
      return Left(DataSource.cacheError.getFailure());
    }
  }
}
