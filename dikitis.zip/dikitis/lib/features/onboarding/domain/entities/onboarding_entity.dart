class Onboarding {
  final String imageAsset;
  final String title;
  final String description;

  Onboarding({
    required this.imageAsset,
    required this.title,
    required this.description,
  });
}
