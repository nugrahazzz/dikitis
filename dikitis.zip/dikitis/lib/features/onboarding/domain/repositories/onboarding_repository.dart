import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';

abstract class OnboardingRepository {
  Future<Either<Failure, List<Onboarding>>> getOnboardingInfo();

  Future<Either<Failure, bool>> checkIfOnboardingViewed();

  Future<Either<Failure, void>> setOnboardingViewed(bool status);
}
