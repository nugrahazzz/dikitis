import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';

class SetOnboardingViewedUseCase implements UseCase<void, Params<bool>> {
  final OnboardingRepository repository;

  SetOnboardingViewedUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(Params params) {
    return repository.setOnboardingViewed(params.data);
  }
}
