import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';

class CheckIfOnboardingViewedUseCase implements UseCase<bool, NoParams> {
  final OnboardingRepository repository;

  CheckIfOnboardingViewedUseCase(this.repository);

  @override
  Future<Either<Failure, bool>> call(NoParams params) {
    return repository.checkIfOnboardingViewed();
  }
}
