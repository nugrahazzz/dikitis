import 'package:dartz/dartz.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';

class GetOnboardingInfoUseCase implements UseCase<List<Onboarding>, NoParams> {
  final OnboardingRepository repository;

  GetOnboardingInfoUseCase(this.repository);

  @override
  Future<Either<Failure, List<Onboarding>>> call(NoParams params) {
    return repository.getOnboardingInfo();
  }
}
