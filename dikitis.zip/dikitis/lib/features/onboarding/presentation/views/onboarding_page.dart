import 'package:carousel_slider/carousel_slider.dart';
import 'package:dikitis/core/components/global_components.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/constant/styles/text_styles.dart';
import 'package:dikitis/core/utils/extensions/global_extensions.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';
import 'package:dikitis/features/onboarding/presentation/controllers/onboarding_controller.dart';
import 'package:double_back_to_close/double_back_to_close.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OnboardingPage extends GetView<OnboardingController> {
  const OnboardingPage({super.key});

  @override
  Widget build(BuildContext context) {
    changeBarColor(
      statusBarColor: AppColors.transparent,
      navBarColor: AppColors.bgDark,
    );
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      body: SafeArea(
        child: DoubleBack(
          onFirstBackPress: (context) {
            showCustomSnackBar(title: "pressMore".tr, description: "toLeave".tr);
          },
          waitForSecondBackPress: 3,
          child: controller.obx(
            (List<Onboarding> state) => Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                // Carousel
                CarouselSlider.builder(
                  options: CarouselOptions(
                    height: 82.0.wp,
                    initialPage: 0,
                    enlargeCenterPage: true,
                    autoPlay: false,
                    reverse: false,
                    enableInfiniteScroll: false,
                    scrollDirection: Axis.horizontal,
                    onPageChanged: (index, reason) {
                      controller.currentPosition.value = index;
                    },
                  ),
                  carouselController: controller.pageController,
                  itemCount: state.length,
                  itemBuilder: (BuildContext context, int itemIndex, int idAnimation) {
                    final page = state[itemIndex];
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          vertical: 10.0.wp,
                          horizontal: 1.0.wp,
                        ),
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(page.imageAsset),
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    );
                  },
                ),
                SizedBox(height: 12.0.wp),
                // Caption
                SizedBox(
                  width: 78.0.wp,
                  child: Column(
                    children: <Widget>[
                      Text(
                        state[controller.currentPosition.value].title,
                        style: AppTextStyles.poppinsBold.copyWith(
                          color: AppColors.white,
                          fontSize: 4.5.wp,
                        ),
                      ),
                      SizedBox(height: 2.0.wp),
                      Text(
                        state[controller.currentPosition.value].description,
                        textAlign: TextAlign.center,
                        style: AppTextStyles.poppinsMedium.copyWith(
                          color: AppColors.white,
                          fontSize: 3.2.wp,
                          wordSpacing: 0.6,
                          letterSpacing: 0.7,
                          fontWeight: FontWeight.w600,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 8.0.wp),
                // Indicator
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: List.generate(
                    state.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: EdgeInsets.symmetric(horizontal: 1.2.wp),
                      width: (controller.currentPosition.value == index) ? 5.0.wp : 2.0.wp,
                      height: 2.0.wp,
                      decoration: BoxDecoration(
                        color: controller.currentPosition.value == index ? AppColors.white : AppColors.white.withValues(alpha: 0.4),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10.0.wp),
                // Button
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.0.wp),
                  child: Row(
                    children: [
                      AnimatedContainer(
                        height: 15.0.wp,
                        width: controller.currentPosition.value != 0 ? 16.0.wp : 0,
                        duration: const Duration(milliseconds: 300),
                        child: Container(
                          height: 7.5.wp,
                          margin: EdgeInsets.only(right: 3.5.wp),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: CustomButton(
                            width: controller.currentPosition.value != 0 ? 8.0.wp : 0,
                            onlyIcon: true,
                            function: () {
                              controller.prevPage();
                            },
                            color: AppColors.white,
                            icons: controller.currentPosition.value != 0 ? Icons.arrow_back_ios_new : null,
                            borderRadius: 12,
                          ),
                        ),
                      ),
                      Expanded(
                        child: CustomButton(
                          onlyIcon: false,
                          function: controller.forwardAction,
                          color: AppColors.white,
                          titleColor: AppColors.bgDark,
                          title: controller.isLastPage ? 'end'.tr : 'next'.tr,
                          fontSize: 4.5.wp,
                          height: 15.0.wp,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 9.0.wp),
              ],
            ),
            onLoading: const CustomLoading(),
            onEmpty: const CustomEmpty(),
            onError: (String? error) => CustomError(
              errorMessage: error.toString(),
              function: () {
                controller.onReady();
              },
            ),
          ),
        ),
      ),
    );
  }
}
