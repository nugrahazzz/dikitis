// import 'package:dikitis/config/routes/routes.dart';
// import 'package:dikitis/features/onboarding/presentation/controllers/onboarding_controller.dart';
// import 'package:get/get.dart';
//
// class OnboardingMiddleware extends GetMiddleware {
//   @override
//   Future<RouteDecoder?> redirectDelegate(RouteDecoder route) async {
//     // final onboardingC = Bind.find<OnboardingController>();
//     final bool hasViewedOnboarding = await Bind.find<OnboardingController>().checkIfOnboardingViewed();
//
//     if (hasViewedOnboarding) {
//       return RouteDecoder.fromRoute(Routes.authenticationPage);
//     } else {
//       return RouteDecoder.fromRoute(Routes.onboardingPage);
//     }
//   }
// }
