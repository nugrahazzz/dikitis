import 'package:carousel_slider/carousel_controller.dart';
import 'package:dartz/dartz.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/core/error/failure.dart';
import 'package:dikitis/core/utils/functions/global_functions.dart';
import 'package:dikitis/core/utils/helper/use_case.dart';
import 'package:dikitis/features/onboarding/domain/entities/onboarding_entity.dart';
import 'package:dikitis/features/onboarding/domain/usecases/get_onboarding_info.dart';
import 'package:dikitis/features/onboarding/domain/usecases/set_onboarding_viewed.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OnboardingController extends GetxController with StateMixin<List<Onboarding>> {
  final GetOnboardingInfoUseCase getOnboardingInfoUseCase;
  final SetOnboardingViewedUseCase setOnboardingViewedUseCase;

  OnboardingController({
    required this.getOnboardingInfoUseCase,
    required this.setOnboardingViewedUseCase,
  });

  RxInt currentPosition = 0.obs;

  bool get isLastPage => currentPosition.value == state.length - 1;

  bool get isFirstPage => currentPosition.value == 0;

  late CarouselSliderController pageController;

  @override
  void onInit() {
    super.onInit();
    pageController = CarouselSliderController();
    futurize(() => getListOnboardingPages());
  }

  @override
  void onClose() {
    //    Get.delete<OnboardingController>();
    super.onClose();
  }

  Future<List<Onboarding>> getListOnboardingPages() async {
    final Either<Failure, List<Onboarding>> results = await getOnboardingInfoUseCase(NoParams());

    return results.fold((Failure failure) {
      //failed
      throw "${failure.message} \n (error code: ${failure.code})";
    }, (List<Onboarding> data) {
      //success
      return data;
    });
  }

  Future<void> setOnboardingViewed() async {
    final Either<Failure, void> results = await setOnboardingViewedUseCase(Params(true));
    return results.fold((Failure failure) {
      //failed
      showCustomSnackBar(title: failure.message, description: "(Error code: ${failure.code})");
    }, (_) {
      //success
      Get.offNamed(Routes.authenticationPage);
    });
  }

  void prevPage() {
    if (!isFirstPage) {
      pageController.previousPage(duration: const Duration(milliseconds: 300), curve: Curves.linear);
    }
  }

  void forwardAction() {
    if (isLastPage) {
      // LocalStorageServices().pageHasSeen(Routes.onboardingPage).then(
      //       (value) => Get.offAllNamed(Routes.authenticationPage),
      // );

      setOnboardingViewed();
      Get.offAllNamed(Routes.authenticationPage);
    } else {
      pageController.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.linear);
    }
  }
}
