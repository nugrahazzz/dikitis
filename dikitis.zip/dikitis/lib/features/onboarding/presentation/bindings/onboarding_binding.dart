import 'package:dikitis/features/onboarding/data/data_source/onboarding_local_data_source.dart';
import 'package:dikitis/features/onboarding/data/repositories/onboarding_repository_impl.dart';
import 'package:dikitis/features/onboarding/domain/repositories/onboarding_repository.dart';
import 'package:dikitis/features/onboarding/domain/usecases/check_if_onboarding_viewed.dart';
import 'package:dikitis/features/onboarding/domain/usecases/get_onboarding_info.dart';
import 'package:dikitis/features/onboarding/domain/usecases/set_onboarding_viewed.dart';
import 'package:dikitis/features/onboarding/presentation/controllers/onboarding_controller.dart';
import 'package:get/get.dart';

class OnboardingBinding extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      //Controller
      Bind.lazyPut(
        () => OnboardingController(
          getOnboardingInfoUseCase: Get.find(),
          setOnboardingViewedUseCase: Get.find(),
        ),
      ),
      //Datasource
      Bind.lazyPut<OnboardingLocalDataSource>(
        () => OnboardingLocalDataSourceImpl(
          databaseService: Get.find(),
        ),
      ),
      //Repository
      Bind.lazyPut<OnboardingRepository>(
        () => OnboardingRepositoryImpl(
          localDataSource: Get.find(),
        ),
      ),
      //Usecase
      Bind.lazyPut(() => GetOnboardingInfoUseCase(Get.find())),
      Bind.lazyPut(() => CheckIfOnboardingViewedUseCase(Get.find())),
      Bind.lazyPut(() => SetOnboardingViewedUseCase(Get.find())),
    ];
  }
}
