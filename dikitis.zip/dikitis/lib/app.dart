import 'package:dikitis/config/routes/pages.dart';
import 'package:dikitis/config/routes/routes.dart';
import 'package:dikitis/config/translations/localization_translations.dart';
import 'package:dikitis/core/constant/styles/colors.dart';
import 'package:dikitis/core/services/database_service.dart';
import 'package:dikitis/core/services/rest_api_service.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      enableLog: true,
      //
      color: AppColors.bgDark,
      // theme: AppStyles.theme.defaultTheme,
      defaultTransition: Transition.fadeIn,
      //
      locale: Get.deviceLocale,
      fallbackLocale: LocalizationTranslations.engLocale,
      translations: LocalizationTranslations(),
      //
      getPages: Pages.getPages,
      initialRoute: Routes.splashPage,
      //initial binding
      binds: [
        Bind.lazyPut(() => Dio(), fenix: true),
        Bind.lazyPut<GetStorage>(GetStorage.new, fenix: true),
        //
        Bind.lazyPut<RestApiService>(() => RestApiService(dio: Get.find()), fenix: true),
        Bind.lazyPut<DatabaseService>(() => DatabaseService(), fenix: true),
        //
        // Bind.lazyPut<LocalizationTranslations>(() => LocalizationTranslations(storage: Get.find<GetStorage>())),
      ],
    );
  }
}

//perubahan
//memperbaiki tata letak perubahan perubahan bahasa
//memperbaiki dialog tidak terclose pada skenario tertentu
//memperbaiki render animasi pada lisensi atribusi saat dialog muncul
